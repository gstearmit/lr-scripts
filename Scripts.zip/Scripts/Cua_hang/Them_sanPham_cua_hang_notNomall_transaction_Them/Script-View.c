   !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
   !!                                                                               !!
   !!                    	  PLEASE NOTE											!!
   !!                   	  ===========											!!
   !!                                                                               !!
   !!    This view is a READ-ONLY representation of the script.                     !!
   !!                                                                               !!
   !!    Use the Firefox TruClient sidebar to develop, edit and enhance the script. !!
   !!                                                                               !!
   !!    Select the DEVELOP SCRIPT button to open the Firefox TruClient sidebar.    !!
   !!                                                                               !!
   !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!


F(){
/*
	1	Action:Navigate to "http://bo.ezmall.vn/"
	1	 Start: Home End: Home
*/
		lr_start_transaction("Home");
/*
	4	Action:Type "demo" in Tên đăng nhập textbox
	4	 Start: dang_nhap
*/
		lr_start_transaction("dang_nhap");
/*
	5	Action:Type ●●●●●●●●● in Mật khẩu passwordbox
	8	Action:Type "10002" in Mã cửa hàng textbox
	10	Action:Click on Đăng nhập gridcell
	10	 End: dang_nhap
	12	Action:Click on button button
	12	 Start: Chon_duy_tan
*/
		lr_start_transaction("Chon_duy_tan");
/*
	13	Action:Wait 12 seconds
	13	 End: Chon_duy_tan
	14	Action:Mouse Over
	14	 Start: Chon_cua_hang
*/
		lr_start_transaction("Chon_cua_hang");
/*
	14.3	Action:Move mouse over CỬA HÀNG
	15	Action:Click on CỬA HÀNG
	17	Action:Wait 0,5 seconds
	17	 End: Chon_cua_hang
	18	Action:Click on Thêm mới gridcell
	18	 Start: Them_moi
*/
		lr_start_transaction("Them_moi");
/*
	19	Action:Wait 1 seconds
	21	Action:Type "234sa56tyy76" in Mã vạch textbox
	25	Action:Wait 0,5 seconds
	26	Action:Type "quan" in Tên sản phẩm textbox
	29	Action:Type "Quần Bò" in Tên sản phẩm textbox
	32	Action:Wait 0,5 seconds
	33	Action:Type "1" in Giá bán textbox
	34	Action:Type "7" in Giá bán textbox
	35	Action:Type "0" in Giá bán textbox
	36	Action:Type "0" in Giá bán textbox
	37	Action:Type "0" in Giá bán textbox
	38	Action:Type "0" in Giá bán textbox
	40	Action:Wait 0,5 seconds
	41	Action:Click on element (109)
	45	Action:Wait 0,5 seconds
	46	Action:Select "---Quần bò" from Áo Phông listbox
	49	Action:Wait 0,5 seconds
	50	Action:Type "1" in Giá nhập textbox
	51	Action:Type "1" in Giá nhập textbox
	52	Action:Type "0" in Giá nhập textbox
	53	Action:Type "0" in Giá nhập textbox
	54	Action:Type "0" in Giá nhập textbox
	55	Action:Type "0" in Giá nhập textbox
	57	Action:Wait 3 seconds
	58	Action:Click on Lưu gridcell
	59	Action:Wait 1 seconds
	60	Action:Click on Lưu gridcell
	60	 End: Them_moi
	102	Action:Click on button (12) button
	102	 Start: Chinh_sua_pepsi_cocacola
*/
		lr_start_transaction("Chinh_sua_pepsi_cocacola");
/*
	109	Action:Type "2.000" in 20.000 textbox
	110	Action:Type "20.000" in 20.000 textbox
	114	Action:Type "1" in 10.000 textbox
	115	Action:Type "0" in 10.000 textbox
	116	Action:Type "." in 10.000 textbox
	117	Action:Type "10" in 10.000 textbox
	118	Action:Type "0" in 10.000 textbox
	119	Action:Type "0" in 10.000 textbox
	120	Action:Type "0" in 10.000 textbox
	122	Action:Click on Pepsi textbox
	123	Action:Type " cocacola" in Pepsi textbox
	125	Action:Click on Lưu gridcell
	125	 End: Chinh_sua_pepsi_cocacola
	127	Action:Click on image (4) image
	127	 Start: Xoa_sanPham
*/
		lr_start_transaction("Xoa_sanPham");
/*
	128	Action:Click on image (4) image
	129	Action:Click on image (4) image
	130	Action:Click on image (4) image
	131	Action:Mouse Over
	131.3	Action:Move mouse over button (9) button
	132	Action:Click on button (10) button
	139	Action:Mouse Over
	139.2	Action:Move mouse over Bạn có chắc chắn muốn...
	140	Action:Click on Chấp nhận gridcell
	140	 End: Xoa_sanPham
	159	Action:Click on Đăng xuất gridcell
*/
};
