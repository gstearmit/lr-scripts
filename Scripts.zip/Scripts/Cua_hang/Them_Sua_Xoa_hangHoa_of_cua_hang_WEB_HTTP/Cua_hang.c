Cua_hang()
{

	lr_start_transaction("Cua_hang_trans");

	lr_think_time(28);

	web_submit_data("zkau;jsessionid=030641C2F7D86A1D23CAD254708552D6_3", 
		"Action=http://bo.ezmall.vn/zkau;jsessionid={JSESSIONID5}", 
		"Method=POST", 
		"RecContentType=text/plain", 
		"Referer=http://bo.ezmall.vn/", 
		"Snapshot=t5.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=dtid", "Value=Desktop_29", ENDITEM, 
		"Name=cmd_0", "Value=onAnchorPos", ENDITEM, 
		"Name=uuid_0", "Value=Listbox_1", ENDITEM, 
		"Name=data_0", "Value={\"top\":-1,\"left\":-1}", ENDITEM, 
		"Name=cmd_1", "Value=onClick", ENDITEM, 
		"Name=uuid_1", "Value=Button_4", ENDITEM, 
		"Name=data_1", "Value={\"pageX\":223,\"pageY\":102,\"which\":1,\"x\":46,\"y\":45}", ENDITEM, 
		EXTRARES, 
		"Url=/zkau/web/ec1a8cb9/ezpaging/images/pagination_next.png", "Referer=http://bo.ezmall.vn/", ENDITEM, 
		"Url=/zkau/web/ec1a8cb9/ezpaging/images/pagination_last.png", "Referer=http://bo.ezmall.vn/", ENDITEM, 
		"Url=/media/images/IconTest/edit_icon22x22.png", "Referer=http://bo.ezmall.vn/", ENDITEM, 
		"Url=/zkau/web/ec1a8cb9/sapphire/zul/img/layout/borderlayout-hm.png", "Referer=http://bo.ezmall.vn/zkau/web/ec1a8cb9/_zkiju-sapphire/zul/css/zk.wcs;jsessionid={JSESSIONID5}", ENDITEM, 
		LAST);

	lr_end_transaction("Cua_hang_trans",LR_AUTO);

	lr_think_time(3);

	return 0;
}
