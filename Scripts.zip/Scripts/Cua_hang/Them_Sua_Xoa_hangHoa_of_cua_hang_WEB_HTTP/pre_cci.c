# 1 "e:\\scripts hp loadrunner\\07_08_2012\\bo.ezmall.vn\\scripts\\them_sua_xoa_hanghoa_of_cua_hang_web_http\\\\combined_Them_Sua_Xoa_hangHoa_of_cua_hang_WEB_HTTP.c"
# 1 "C:\\Program Files\\HP\\LoadRunner\\include/lrun.h" 1
 
 












 











# 103 "C:\\Program Files\\HP\\LoadRunner\\include/lrun.h"








































































	

 


















 
 
 
 
 


 
 
 
 
 
 














int     lr_start_transaction   (char * transaction_name);
int lr_start_sub_transaction          (char * transaction_name, char * trans_parent);
long lr_start_transaction_instance    (char * transaction_name, long parent_handle);



int     lr_end_transaction     (char * transaction_name, int status);
int lr_end_sub_transaction            (char * transaction_name, int status);
int lr_end_transaction_instance       (long transaction, int status);


 
typedef char* lr_uuid_t;
 



lr_uuid_t lr_generate_uuid();

 


int lr_generate_uuid_free(lr_uuid_t uuid);

 



int lr_generate_uuid_on_buf(lr_uuid_t buf);

   
# 263 "C:\\Program Files\\HP\\LoadRunner\\include/lrun.h"
int lr_start_distributed_transaction  (char * transaction_name, lr_uuid_t correlator, long timeout  );

   







int lr_end_distributed_transaction  (lr_uuid_t correlator, int status);


double lr_stop_transaction            (char * transaction_name);
double lr_stop_transaction_instance   (long parent_handle);


void lr_resume_transaction           (char * trans_name);
void lr_resume_transaction_instance  (long trans_handle);


int lr_update_transaction            (const char *trans_name);


 
void lr_wasted_time(long time);


 
int lr_set_transaction(const char *name, double duration, int status);
 
long lr_set_transaction_instance(const char *name, double duration, int status, long parent_handle);


int   lr_user_data_point                      (char *, double);
long lr_user_data_point_instance                   (char *, double, long);
 



int lr_user_data_point_ex(const char *dp_name, double value, int log_flag);
long lr_user_data_point_instance_ex(const char *dp_name, double value, long parent_handle, int log_flag);


int lr_transaction_add_info      (const char *trans_name, char *info);
int lr_transaction_instance_add_info   (long trans_handle, char *info);
int lr_dpoint_add_info           (const char *dpoint_name, char *info);
int lr_dpoint_instance_add_info        (long dpoint_handle, char *info);


double lr_get_transaction_duration       (char * trans_name);
double lr_get_trans_instance_duration    (long trans_handle);
double lr_get_transaction_think_time     (char * trans_name);
double lr_get_trans_instance_think_time  (long trans_handle);
double lr_get_transaction_wasted_time    (char * trans_name);
double lr_get_trans_instance_wasted_time (long trans_handle);
int    lr_get_transaction_status		 (char * trans_name);
int	   lr_get_trans_instance_status		 (long trans_handle);

 



int lr_set_transaction_status(int status);

 



int lr_set_transaction_status_by_name(int status, const char *trans_name);
int lr_set_transaction_instance_status(int status, long trans_handle);


typedef void* merc_timer_handle_t;
 

merc_timer_handle_t lr_start_timer();
double lr_end_timer(merc_timer_handle_t timer_handle);


 
 
 
 
 
 











 



int   lr_rendezvous  (char * rendezvous_name);
 




int   lr_rendezvous_ex (char * rendezvous_name);



 
 
 
 
 
char *lr_get_vuser_ip (void);
void   lr_whoami (int *vuser_id, char ** sgroup, int *scid);
char *	  lr_get_host_name (void);
char *	  lr_get_master_host_name (void);

 
long     lr_get_attrib_long	(char * attr_name);
char *   lr_get_attrib_string	(char * attr_name);
double   lr_get_attrib_double      (char * attr_name);

char * lr_paramarr_idx(const char * paramArrayName, unsigned int index);
char * lr_paramarr_random(const char * paramArrayName);
int    lr_paramarr_len(const char * paramArrayName);

int	lr_param_unique(const char * paramName);
int lr_param_sprintf(const char * paramName, const char * format, ...);


 
 
static void *ci_this_context = 0;






 








void lr_continue_on_error (int lr_continue);
char *   lr_decrypt (const char *EncodedString);


 
 
 
 
 
 



 







 















void   lr_abort (void);
void lr_exit(int exit_option, int exit_status);
void lr_abort_ex (unsigned long flags);

void   lr_peek_events (void);


 
 
 
 
 


void   lr_think_time (double secs);

 


void lr_force_think_time (double secs);


 
 
 
 
 



















int   lr_msg (char * fmt, ...);
int   lr_debug_message (unsigned int msg_class,
									    char * format,
										...);
# 502 "C:\\Program Files\\HP\\LoadRunner\\include/lrun.h"
void   lr_new_prefix (int type,
                                 char * filename,
                                 int line);
# 505 "C:\\Program Files\\HP\\LoadRunner\\include/lrun.h"
int   lr_log_message (char * fmt, ...);
int   lr_message (char * fmt, ...);
int   lr_error_message (char * fmt, ...);
int   lr_output_message (char * fmt, ...);
int   lr_vuser_status_message (char * fmt, ...);
int   lr_error_message_without_fileline (char * fmt, ...);
int   lr_fail_trans_with_error (char * fmt, ...);

 
 
 
 
 
# 528 "C:\\Program Files\\HP\\LoadRunner\\include/lrun.h"

 
 
 
 
 





int   lr_next_row ( char * table);
int lr_advance_param ( char * param);



														  
														  

														  
														  

													      
 


char *   lr_eval_string (char * str);
int   lr_eval_string_ext (const char *in_str,
                                     unsigned long const in_len,
                                     char ** const out_str,
                                     unsigned long * const out_len,
                                     unsigned long const options,
                                     const char *file,
								     long const line);
# 562 "C:\\Program Files\\HP\\LoadRunner\\include/lrun.h"
void   lr_eval_string_ext_free (char * * pstr);

 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
int lr_param_increment (char * dst_name,
                              char * src_name);
# 585 "C:\\Program Files\\HP\\LoadRunner\\include/lrun.h"













											  
											  

											  
											  
											  

int	  lr_save_var (char *              param_val,
							  unsigned long const param_val_len,
							  unsigned long const options,
							  char *			  param_name);
# 609 "C:\\Program Files\\HP\\LoadRunner\\include/lrun.h"
int   lr_save_string (const char * param_val, const char * param_name);
int   lr_free_parameter (const char * param_name);
int   lr_save_int (const int param_val, const char * param_name);


 
 
 
 
 
 
# 676 "C:\\Program Files\\HP\\LoadRunner\\include/lrun.h"
void   lr_save_datetime (const char *format, int offset, const char *name);









 











 
 
 
 
 






 



char * lr_error_context_get_entry (char * key);

 



long   lr_error_context_get_error_id (void);


 
 
 

int lr_table_get_rows_num (char * param_name);

int lr_table_get_cols_num (char * param_name);

char * lr_table_get_cell_by_col_index (char * param_name, int row, int col);

char * lr_table_get_cell_by_col_name (char * param_name, int row, const char* col_name);

int lr_table_get_column_name_by_index (char * param_name, int col, 
											char * * const col_name,
											int * col_name_len);
# 737 "C:\\Program Files\\HP\\LoadRunner\\include/lrun.h"

int lr_table_get_column_name_by_index_free (char * col_name);


 
 
 
 
 
 
 
 

 
 
 
 
 
 
int   lr_param_substit (char * file,
                                   int const line,
                                   char * in_str,
                                   int const in_len,
                                   char * * const out_str,
                                   int * const out_len);
# 762 "C:\\Program Files\\HP\\LoadRunner\\include/lrun.h"
void   lr_param_substit_free (char * * pstr);


 
# 774 "C:\\Program Files\\HP\\LoadRunner\\include/lrun.h"





char *   lrfnc_eval_string (char * str,
                                      char * file_name,
                                      long const line_num);
# 782 "C:\\Program Files\\HP\\LoadRunner\\include/lrun.h"


int   lrfnc_save_string ( const char * param_val,
                                     const char * param_name,
                                     const char * file_name,
                                     long const line_num);
# 788 "C:\\Program Files\\HP\\LoadRunner\\include/lrun.h"

int   lrfnc_free_parameter (const char * param_name );

int lr_save_searched_string(char *buffer, long buf_size, unsigned int occurrence,
			    char *search_string, int offset, unsigned int param_val_len, 
			    char *param_name);

 
char *   lr_string (char * str);

 
# 859 "C:\\Program Files\\HP\\LoadRunner\\include/lrun.h"

int   lr_save_value (char * param_val,
                                unsigned long const param_val_len,
                                unsigned long const options,
                                char * param_name,
                                char * file_name,
                                long const line_num);
# 866 "C:\\Program Files\\HP\\LoadRunner\\include/lrun.h"


 
 
 
 
 











int   lr_printf (char * fmt, ...);
 
int   lr_set_debug_message (unsigned int msg_class,
                                       unsigned int swtch);
# 888 "C:\\Program Files\\HP\\LoadRunner\\include/lrun.h"
unsigned int   lr_get_debug_message (void);


 
 
 
 
 

void   lr_double_think_time ( double secs);
void   lr_usleep (long);


 
 
 
 
 
 




int *   lr_localtime (long offset);


int   lr_send_port (long port);


# 964 "C:\\Program Files\\HP\\LoadRunner\\include/lrun.h"



struct _lr_declare_identifier{
	char signature[24];
	char value[128];
};

int   lr_pt_abort (void);

void vuser_declaration (void);






# 993 "C:\\Program Files\\HP\\LoadRunner\\include/lrun.h"


# 1005 "C:\\Program Files\\HP\\LoadRunner\\include/lrun.h"
















 
 
 
 
 







int    _lr_declare_transaction   (char * transaction_name);


 
 
 
 
 







int   _lr_declare_rendezvous  (char * rendezvous_name);

 
 
 
 
 

 
int lr_enable_ip_spoofing();
int lr_disable_ip_spoofing();


 




int lr_convert_string_encoding(char *sourceString, char *fromEncoding, char *toEncoding, char *paramName);





 
 

















# 1 "e:\\scripts hp loadrunner\\07_08_2012\\bo.ezmall.vn\\scripts\\them_sua_xoa_hanghoa_of_cua_hang_web_http\\\\combined_Them_Sua_Xoa_hangHoa_of_cua_hang_WEB_HTTP.c" 2

# 1 "globals.h" 1



 
 

# 1 "C:\\Program Files\\HP\\LoadRunner\\include/web_api.h" 1
 







# 1 "C:\\Program Files\\HP\\LoadRunner\\include/as_web.h" 1
 






















































 




 








 
 
 

  int
	web_add_filter(
		const char *		mpszArg,
		...
	);									 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 

  int
	web_add_auto_filter(
		const char *		mpszArg,
		...
	);									 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
	
  int
	web_add_auto_header(
		const char *		mpszHeader,
		const char *		mpszValue);

  int
	web_add_header(
		const char *		mpszHeader,
		const char *		mpszValue);
  int
	web_add_cookie(
		const char *		mpszCookie);
  int
	web_cleanup_auto_headers(void);
  int
	web_cleanup_cookies(void);
  int
	web_concurrent_end(
		const char * const	mpszReserved,
										 
		...								 
	);
  int
	web_concurrent_start(
		const char * const	mpszConcurrentGroupName,
										 
										 
		...								 
										 
	);
  int
	web_create_html_param(
		const char *		mpszParamName,
		const char *		mpszLeftDelim,
		const char *		mpszRightDelim);
  int
	web_create_html_param_ex(
		const char *		mpszParamName,
		const char *		mpszLeftDelim,
		const char *		mpszRightDelim,
		const char *		mpszNum);
  int
	web_custom_request(
		const char *		mpszReqestName,
		...);							 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
  int
	web_disable_keep_alive(void);
  int
	web_enable_keep_alive(void);
  int
	web_find(
		const char *		mpszStepName,
		...);							 
										 
										 
										 
										 
										 
										 
										 
										 
										 
  int
	web_get_int_property(
		const int			miHttpInfoType);
  int
	web_image(
		const char *		mpszStepName,
		...);							 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
  int
	web_image_check(
		const char *		mpszName,
		...);
  int
	web_java_check(
		const char *		mpszName,
		...);
  int
	web_link(
		const char *		mpszStepName,
		...);							 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 

	
  int
	web_global_verification(
		const char *		mpszArg1,
		...);							 
										 
										 
										 
										 
										 

  int
	web_reg_find(
		const char *		mpszArg1,
		...);							 
										 
										 
										 
										 
										 
										 
										 
				
  int
	web_reg_save_param(
		const char *		mpszParamName,
		...);							 
										 
										 
										 
										 
										 
										 

  int
	web_convert_param(
		const char * 		mpszParamName, 
										 
		...);							 
										 
										 


										 

										 
  int
	web_remove_auto_filter(
		const char *		mpszArg,
		...
	);									 
										 
				
  int
	web_remove_auto_header(
		const char *		mpszHeaderName,
		...);							 
										 



  int
	web_remove_cookie(
		const char *		mpszCookie);

  int
	web_save_header(
		const char *		mpszType,	 
		const char *		mpszName);	 
  int
	web_set_certificate(
		const char *		mpszIndex);
  int
	web_set_certificate_ex(
		const char *		mpszArg1,
		...);							 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
  int
	web_set_connections_limit(
		const char *		mpszLimit);
  int
	web_set_max_html_param_len(
		const char *		mpszLen);
  int
	web_set_max_retries(
		const char *		mpszMaxRetries);
  int
	web_set_proxy(
		const char *		mpszProxyHost);
  int
	web_set_proxy_bypass(
		const char *		mpszBypass);
  int
	web_set_secure_proxy(
		const char *		mpszProxyHost);
  int
	web_set_sockets_option(
		const char *		mpszOptionID,
		const char *		mpszOptionValue
	);
  int
	web_set_option(
		const char *		mpszOptionID,
		const char *		mpszOptionValue,
		...								 
	);
  int
	web_set_timeout(
		const char *		mpszWhat,
		const char *		mpszTimeout);
  int
	web_set_user(
		const char *		mpszUserName,
		const char *		mpszPwd,
		const char *		mpszHost);

  int
	web_sjis_to_euc_param(
		const char *		mpszParamName,
										 
		const char *		mpszParamValSjis);
										 

  int
	web_submit_data(
		const char *		mpszStepName,
		...);							 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
  int
	web_submit_form(
		const char *		mpszStepName,
		...);							 
										 
										 
										 
										 
										 
										 
										 
										 
										  
										 
										 
										 
										 
										 
										  
										 
										 
										 
										 
										 
										 
										 
										  
										 
										 
										 
										 
										 
										  
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
  int
	web_url(
		const char *		mpszUrlName,
		...);							 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 

  int 
	web_set_proxy_bypass_local(
		const char * mpszNoLocal
		);

  int 
	web_cache_cleanup(void);

  int
	web_create_html_query(
		const char* mpszStartQuery,
		...);							 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 

  int 
	web_create_radio_button_param(
		const char *NameFiled,
		const char *NameAndVal,
		const char *ParamName
		);

  int
	web_convert_from_formatted(
		const char * mpszArg1,
		...);							 
										 
										 
										 
										 
										 
										
  int
	web_convert_to_formatted(
		const char * mpszArg1,
		...);							 
										 
										 
										 
										 
										 

  int
	web_reg_save_param_ex(
		const char * mpszParamName,
		...);							 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 

  int
	web_reg_save_param_xpath(
		const char * mpszParamName,
		...);							
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 










# 596 "C:\\Program Files\\HP\\LoadRunner\\include/as_web.h"


# 609 "C:\\Program Files\\HP\\LoadRunner\\include/as_web.h"



























# 647 "C:\\Program Files\\HP\\LoadRunner\\include/as_web.h"

 
 
 


  int
	FormSubmit(
		const char *		mpszFormName,
		...);
  int
	InitWebVuser(void);
  int
	SetUser(
		const char *		mpszUserName,
		const char *		mpszPwd,
		const char *		mpszHost);
  int
	TerminateWebVuser(void);
  int
	URL(
		const char *		mpszUrlName);
























# 715 "C:\\Program Files\\HP\\LoadRunner\\include/as_web.h"



 
 
 






# 10 "C:\\Program Files\\HP\\LoadRunner\\include/web_api.h" 2












 






 











  int
	web_reg_add_cookie(
		const char *		mpszCookie,
		...);							 
										 

  int
	web_report_data_point(
		const char *		mpszEventType,
		const char *		mpszEventName,
		const char *		mpszDataPointName,
		const char *		mpszLAST);	 
										 
										 
										 

  int
	web_text_link(
		const char *		mpszStepName,
		...);

  int
	web_element(
		const char *		mpszStepName,
		...);

  int
	web_image_link(
		const char *		mpszStepName,
		...);

  int
	web_static_image(
		const char *		mpszStepName,
		...);

  int
	web_image_submit(
		const char *		mpszStepName,
		...);

  int
	web_button(
		const char *		mpszStepName,
		...);

  int
	web_edit_field(
		const char *		mpszStepName,
		...);

  int
	web_radio_group(
		const char *		mpszStepName,
		...);

  int
	web_check_box(
		const char *		mpszStepName,
		...);

  int
	web_list(
		const char *		mpszStepName,
		...);

  int
	web_text_area(
		const char *		mpszStepName,
		...);

  int
	web_map_area(
		const char *		mpszStepName,
		...);

  int
	web_eval_java_script(
		const char *		mpszStepName,
		...);

  int
	web_reg_dialog(
		const char *		mpszArg1,
		...);

  int
	web_reg_cross_step_download(
		const char *		mpszArg1,
		...);

  int
	web_browser(
		const char *		mpszStepName,
		...);

  int
	web_control(
		const char *		mpszStepName,
		...);

  int
	web_set_rts_key(
		const char *		mpszArg1,
		...);

  int
	web_save_param_length(
		const char * 		mpszParamName,
		...);

  int
	web_save_timestamp_param(
		const char * 		mpszParamName,
		...);

  int
	web_load_cache(
		const char *		mpszStepName,
		...);							 
										 

  int
	web_dump_cache(
		const char *		mpszStepName,
		...);							 
										 
										 

  int
	web_reg_find_in_log(
		const char *		mpszArg1,
		...);							 
										 
										 

  int
	web_get_sockets_info(
		const char *		mpszArg1,
		...);							 
										 
										 
										 
										 

  int
	web_add_cookie_ex(
		const char *		mpszArg1,
		...);							 
										 
										 
										 

  int
	web_hook_java_script(
		const char *		mpszArg1,
		...);							 
										 
										 
										 





 
 
 


# 7 "globals.h" 2

# 1 "C:\\Program Files\\HP\\LoadRunner\\include/lrw_custom_body.h" 1
 





# 8 "globals.h" 2


 
 


# 2 "e:\\scripts hp loadrunner\\07_08_2012\\bo.ezmall.vn\\scripts\\them_sua_xoa_hanghoa_of_cua_hang_web_http\\\\combined_Them_Sua_Xoa_hangHoa_of_cua_hang_WEB_HTTP.c" 2

# 1 "vuser_init.c" 1
vuser_init()
{
	web_set_max_html_param_len("1024");

	 



	web_reg_save_param("JSESSIONID5", 
		"LB/IC=jsessionid=", 
		"RB/IC=\"", 
		"Ord=1", 
		"Search=body", 
		"RelFrameId=1", 
		"LAST");
	return 0;
}
# 3 "e:\\scripts hp loadrunner\\07_08_2012\\bo.ezmall.vn\\scripts\\them_sua_xoa_hanghoa_of_cua_hang_web_http\\\\combined_Them_Sua_Xoa_hangHoa_of_cua_hang_WEB_HTTP.c" 2

# 1 "Action.c" 1
Action()
{

	
	web_set_max_html_param_len("1024");

	 



	web_reg_save_param("JSESSIONID5", 
		"LB/IC=jsessionid=", 
		"RB/IC=\"", 
		"Ord=1", 
		"Search=body", 
		"RelFrameId=1", 
		"LAST");

	web_url("bo.ezmall.vn", 
		"URL=http://bo.ezmall.vn/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		"EXTRARES", 
		"Url=/zkau/web/ec1a8cb9/sapphire/zul/img/misc/progress.gif", "Referer=http://bo.ezmall.vn/zkau/web/ec1a8cb9/_zkiju-sapphire/zul/css/zk.wcs;jsessionid={JSESSIONID5}", "ENDITEM", 
		"Url=/media/images/maybanhang.png", "Referer=http://bo.ezmall.vn/media/css/ezstore.css.dsp;jsessionid={JSESSIONID5}", "ENDITEM", 
		"Url=/zkau/web/_zv2013032614/js/zul.layout.wpd;jsessionid={JSESSIONID5}", "ENDITEM", 
		"Url=/zkau/web/_zv2013032614/js/zul.box.wpd;jsessionid={JSESSIONID5}", "ENDITEM", 
		"Url=/zkau/web/_zv2013032614/js/zul.inp.wpd;jsessionid={JSESSIONID5}", "ENDITEM", 
		"Url=/zkau/web/_zv2013032614/js/zul.wnd.wpd;jsessionid={JSESSIONID5}", "ENDITEM", 
		"Url=/zkau/web/_zv2013032614/js/zul.sel.wpd;jsessionid={JSESSIONID5}", "ENDITEM", 
		"Url=/zkau/web/_zv2013032614/js/zul.mesh.wpd;jsessionid={JSESSIONID5}", "ENDITEM", 
		"Url=/zkau/web/_zv2013032614/js/zk.fmt.wpd;jsessionid={JSESSIONID5}", "ENDITEM", 
		"Url=/zkau/web/_zv2013032614/js/zul.menu.wpd;jsessionid={JSESSIONID5}", "ENDITEM", 
		"Url=/media/images/IconTest/maybanhang_logo_251x44.png;jsessionid={JSESSIONID5}", "ENDITEM", 
		"Url=/media/images/icon_header/location_icon_16x21.png;jsessionid={JSESSIONID5}", "ENDITEM", 
		"Url=/media/images/icon_header/support_icon_25x25.png;jsessionid={JSESSIONID5}", "ENDITEM", 
		"Url=/media/images/icon_header/dashboard52x52.png;jsessionid={JSESSIONID5}", "ENDITEM", 
		"Url=/media/images/icon_header/cuahang52x52.png;jsessionid={JSESSIONID5}", "ENDITEM", 
		"Url=/media/images/vi.png;jsessionid={JSESSIONID5}", "ENDITEM", 
		"Url=/media/images/icon_header/khachhang52x52.png;jsessionid={JSESSIONID5}", "ENDITEM", 
		"Url=/media/images/icon_header/khohang52x52.png;jsessionid={JSESSIONID5}", "ENDITEM", 
		"Url=/media/images/icon_header/cash52x52.png;jsessionid={JSESSIONID5}", "ENDITEM", 
		"Url=/media/images/icon_header/order52x52.png;jsessionid={JSESSIONID5}", "ENDITEM", 
		"Url=/media/images/icon_header/baocao52x52.png;jsessionid={JSESSIONID5}", "ENDITEM", 
		"Url=/media/images/icon_header/invoice52x52.png;jsessionid={JSESSIONID5}", "ENDITEM", 
		"Url=/media/images/icon_header/email52x52.png;jsessionid={JSESSIONID5}", "ENDITEM", 
		"Url=/media/images/icon_header/setting52x52.png;jsessionid={JSESSIONID5}", "ENDITEM", 
		"Url=/media/images/icon_header/taikhoan52x52.png;jsessionid={JSESSIONID5}", "ENDITEM", 
		"Url=/media/images/icon_header/nhanvien52x52.png;jsessionid={JSESSIONID5}", "ENDITEM", 
		"Url=/media/images/icon_header/support52x52.png;jsessionid={JSESSIONID5}", "ENDITEM", 
		"Url=/zkau/web/ec1a8cb9/sapphire/zul/img/splt/colps-t.png", "Referer=http://bo.ezmall.vn/zkau/web/ec1a8cb9/_zkiju-sapphire/zul/css/zk.wcs;jsessionid={JSESSIONID5}", "ENDITEM", 
		"Url=/zkau/web/ec1a8cb9/sapphire/zul/img/splt/splt-v.png", "Referer=http://bo.ezmall.vn/zkau/web/ec1a8cb9/_zkiju-sapphire/zul/css/zk.wcs;jsessionid={JSESSIONID5}", "ENDITEM", 
		"Url=/zkau/web/ec1a8cb9/sapphire/zul/img/splt/splt-h.png", "Referer=http://bo.ezmall.vn/zkau/web/ec1a8cb9/_zkiju-sapphire/zul/css/zk.wcs;jsessionid={JSESSIONID5}", "ENDITEM", 
		"LAST");

	return 0;
}
# 4 "e:\\scripts hp loadrunner\\07_08_2012\\bo.ezmall.vn\\scripts\\them_sua_xoa_hanghoa_of_cua_hang_web_http\\\\combined_Them_Sua_Xoa_hangHoa_of_cua_hang_WEB_HTTP.c" 2

# 1 "dang_nhap.c" 1
dang_nhap()
{

	lr_start_transaction("dang_nhap_tran");

	lr_think_time(51);

	web_submit_data("zkau;jsessionid=030641C2F7D86A1D23CAD254708552D6", 
		"Action=http://bo.ezmall.vn/zkau;jsessionid={JSESSIONID5}", 
		"Method=POST", 
		"RecContentType=text/plain", 
		"Referer=http://bo.ezmall.vn/", 
		"Snapshot=t2.inf", 
		"Mode=HTML", 
		"ITEMDATA", 
		"Name=dtid", "Value=Desktop_29", "ENDITEM", 
		"Name=cmd_0", "Value=onChange", "ENDITEM", 
		"Name=uuid_0", "Value=Textbox_1", "ENDITEM", 
		"Name=data_0", "Value={\"value\":\"demo\",\"start\":4}", "ENDITEM", 
		"Name=cmd_1", "Value=onChange", "ENDITEM", 
		"Name=uuid_1", "Value=Textbox_2", "ENDITEM", 
		"Name=data_1", "Value={\"value\":\"mbh2012\",\"start\":7}", "ENDITEM", 
		"Name=cmd_2", "Value=onChange", "ENDITEM", 
		"Name=uuid_2", "Value=Textbox_3", "ENDITEM", 
		"Name=data_2", "Value={\"value\":\"10002\",\"start\":5}", "ENDITEM", 
		"Name=cmd_3", "Value=onClick", "ENDITEM", 
		"Name=uuid_3", "Value=Button_18", "ENDITEM", 
		"Name=data_3", "Value={\"pageX\":533,\"pageY\":454,\"which\":1,\"x\":74,\"y\":27}", "ENDITEM", 
		"EXTRARES", 
		"Url=/zkau/web/ec1a8cb9/sapphire/zul/img/wnd/wnd-ol-corner.png", "Referer=http://bo.ezmall.vn/zkau/web/ec1a8cb9/_zkiju-sapphire/zul/css/zk.wcs;jsessionid={JSESSIONID5}", "ENDITEM", 
		"Url=/zkau/web/ec1a8cb9/sapphire/zul/img/wnd/wnd-ol-hm.png", "Referer=http://bo.ezmall.vn/zkau/web/ec1a8cb9/_zkiju-sapphire/zul/css/zk.wcs;jsessionid={JSESSIONID5}", "ENDITEM", 
		"Url=/media/images/chon-cua-hang-1_05.gif", "Referer=http://bo.ezmall.vn/media/css/style_vi.css.dsp;jsessionid={JSESSIONID5}", "ENDITEM", 
		"Url=/media/images/chon-cua-hang-1_08.gif", "Referer=http://bo.ezmall.vn/media/css/style_vi.css.dsp;jsessionid={JSESSIONID5}", "ENDITEM", 
		"Url=/media/images/IconTest/triagle_btn_15x13.png", "Referer=http://bo.ezmall.vn/media/css/style_vi.css.dsp;jsessionid={JSESSIONID5}", "ENDITEM", 
		"LAST");

	lr_end_transaction("dang_nhap_tran",2);

	lr_think_time(3);

	return 0;
}
# 5 "e:\\scripts hp loadrunner\\07_08_2012\\bo.ezmall.vn\\scripts\\them_sua_xoa_hanghoa_of_cua_hang_web_http\\\\combined_Them_Sua_Xoa_hangHoa_of_cua_hang_WEB_HTTP.c" 2

# 1 "Chon_duy_tan_CH.c" 1
Chon_duy_tan_CH()
{

	lr_start_transaction("duy_tan_trans");

	web_add_cookie("PREF=ID=6669a4bc5f8cbeaf:U=700ad4a2d3d15391:FF=0:TM=1372252149:LM=1372654812:S=xP580yOB-wz-T-eF; DOMAIN=safebrowsing.clients.google.com");

	web_add_cookie("NID=67=BQh52riVuK5Is3zTV8yWjgMztvSx4193H3X2paH1LFILZVlMKPQaTnec4r6QX-IE4G-RlW9uTdDOHZIxccEilH02U6ycnrKLm5Uvn0U8rs9VcHxKEyCT-Upihdc_S6id; DOMAIN=safebrowsing.clients.google.com");

	web_add_cookie("PREF=ID=6669a4bc5f8cbeaf:U=700ad4a2d3d15391:FF=0:TM=1372252149:LM=1372654812:S=xP580yOB-wz-T-eF; DOMAIN=safebrowsing-cache.google.com");

	web_add_cookie("NID=67=BQh52riVuK5Is3zTV8yWjgMztvSx4193H3X2paH1LFILZVlMKPQaTnec4r6QX-IE4G-RlW9uTdDOHZIxccEilH02U6ycnrKLm5Uvn0U8rs9VcHxKEyCT-Upihdc_S6id; DOMAIN=safebrowsing-cache.google.com");

	lr_think_time(34);

	web_custom_request("downloads", 
		"URL=http://safebrowsing.clients.google.com/safebrowsing/downloads?client=navclient-auto-ffox&appver=22.0&pver=2.2&wrkey=AKEgNivl4yvaBoE3f0-e0F49dLRc927ds_EOrJANA8Tj9e3JYIGzl4AI0zk_IXRylBc9za-MD-ykVjRa8e8ltLgewABxZhExWA==", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/vnd.google.safebrowsing-update", 
		"Referer=", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		"EncType=text/plain", 
		"Body=goog-malware-shavar;a:111607-120465:s:110081-117436:mac\ngoog-phish-shavar;a:284273-292146:s:136714-140953:mac\n", 
		"EXTRARES", 
		"Url=http://safebrowsing-cache.google.com/safebrowsing/rd/ChNnb29nLW1hbHdhcmUtc2hhdmFyEAEYuZUHIL6VBzIFucoBAD8", "Referer=", "ENDITEM", 
		"Url=http://safebrowsing-cache.google.com/safebrowsing/rd/ChNnb29nLW1hbHdhcmUtc2hhdmFyEAEYv5UHIMSVBzIFv8oBAD8", "Referer=", "ENDITEM", 
		"Url=http://safebrowsing-cache.google.com/safebrowsing/rd/ChNnb29nLW1hbHdhcmUtc2hhdmFyEAEYwZUHIICYByofKssBAP__________________________________fzISwcoBAP________________8B", "Referer=", "ENDITEM", 
		"Url=http://safebrowsing-cache.google.com/safebrowsing/rd/"
		"ChNnb29nLW1hbHdhcmUtc2hhdmFyEAAYgawHIIDAByqeAjfXAQD______________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________wMyKwHWAQD__________________________________________________z8", "Referer=", "ENDITEM", 
		"Url=http://safebrowsing-cache.google.com/safebrowsing/rd/ChFnb29nLXBoaXNoLXNoYXZhchABGJnNCCCezQgyBZkmAgA_", "Referer=", "ENDITEM", 
		"Url=http://safebrowsing-cache.google.com/safebrowsing/rd/ChFnb29nLXBoaXNoLXNoYXZhchABGJ_NCCCkzQgyBZ8mAgA_", "Referer=", "ENDITEM", 
		"Url=http://safebrowsing-cache.google.com/safebrowsing/rd/ChFnb29nLXBoaXNoLXNoYXZhchABGKHNCCDAzggqBjcnAgD_AzIXoSYCAP_______________________z8", "Referer=", "ENDITEM", 
		"Url=http://safebrowsing-cache.google.com/safebrowsing/rd/ChFnb29nLXBoaXNoLXNoYXZhchAAGLPqESC46hEyBTN1BAA_", "Referer=", "ENDITEM", 
		"Url=http://safebrowsing-cache.google.com/safebrowsing/rd/ChFnb29nLXBoaXNoLXNoYXZhchAAGLfqESDA6hEyBjd1BAD_Aw", "Referer=", "ENDITEM", 
		"Url=http://safebrowsing-cache.google.com/safebrowsing/rd/ChFnb29nLXBoaXNoLXNoYXZhchAAGMHqESCA7REqECR2BAD______________x8yIUF1BAD_____________________________________Bw", "Referer=", "ENDITEM", 
		"LAST");

	web_submit_data("zkau;jsessionid=030641C2F7D86A1D23CAD254708552D6_2", 
		"Action=http://bo.ezmall.vn/zkau;jsessionid={JSESSIONID5}", 
		"Method=POST", 
		"RecContentType=text/plain", 
		"Referer=http://bo.ezmall.vn/", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		"ITEMDATA", 
		"Name=dtid", "Value=Desktop_29", "ENDITEM", 
		"Name=cmd_0", "Value=onMove", "ENDITEM", 
		"Name=opt_0", "Value=i", "ENDITEM", 
		"Name=uuid_0", "Value=AA008ChooseLocationWindow_1", "ENDITEM", 
		"Name=data_0", "Value={\"left\":\"309px\",\"top\":\"118px\"}", "ENDITEM", 
		"Name=cmd_1", "Value=onZIndex", "ENDITEM", 
		"Name=opt_1", "Value=i", "ENDITEM", 
		"Name=uuid_1", "Value=AA008ChooseLocationWindow_1", "ENDITEM", 
		"Name=data_1", "Value={\"\":1800}", "ENDITEM", 
		"Name=cmd_2", "Value=onMove", "ENDITEM", 
		"Name=opt_2", "Value=i", "ENDITEM", 
		"Name=uuid_2", "Value=AA008ChooseLocationWindow_1", "ENDITEM", 
		"Name=data_2", "Value={\"left\":\"309px\",\"top\":\"117px\"}", "ENDITEM", 
		"Name=cmd_3", "Value=onClick", "ENDITEM", 
		"Name=uuid_3", "Value=Button_20", "ENDITEM", 
		"Name=data_3", "Value={\"pageX\":438,\"pageY\":255,\"which\":1,\"x\":37,\"y\":45.5}", "ENDITEM", 
		"EXTRARES", 
		"Url=/zkau/web/_zv2013032614/js/zhtml.wpd;jsessionid={JSESSIONID5}", "Referer=http://bo.ezmall.vn/", "ENDITEM", 
		"Url=/zkau/web/_zv2013032614/js/zul.fchart2.wpd;jsessionid={JSESSIONID5}", "Referer=http://bo.ezmall.vn/", "ENDITEM", 
		"Url=/zkau/web/_zv2013032614/js/zkex.grid.wpd;jsessionid={JSESSIONID5}", "Referer=http://bo.ezmall.vn/", "ENDITEM", 
		"Url=/zkau/web/_zv2013032614/js/zul.grid.wpd;jsessionid={JSESSIONID5}", "Referer=http://bo.ezmall.vn/", "ENDITEM", 
		"Url=/zkau/web/_zv2013032614/js/zul.tab.wpd;jsessionid={JSESSIONID5}", "Referer=http://bo.ezmall.vn/", "ENDITEM", 
		"Url=/zkau/web/_zv2013032614/js/zul.db.wpd;jsessionid={JSESSIONID5}", "Referer=http://bo.ezmall.vn/", "ENDITEM", 
		"Url=/zkau/web/_zv2013032614/js/zul.med.wpd;jsessionid={JSESSIONID5}", "Referer=http://bo.ezmall.vn/", "ENDITEM", 
		"Url=/zkau/web/ec1a8cb9/ezpaging/images/pagination_first_dis.png", "Referer=http://bo.ezmall.vn/", "ENDITEM", 
		"Url=/media/images/faq_256.gif", "Referer=http://bo.ezmall.vn/", "ENDITEM", 
		"Url=/zkau/web/ec1a8cb9/ezpaging/images/pagination_prev_dis.png", "Referer=http://bo.ezmall.vn/", "ENDITEM", 
		"Url=/zkau/web/ec1a8cb9/ezpaging/images/load.png", "Referer=http://bo.ezmall.vn/", "ENDITEM", 
		"Url=/zkau/web/ec1a8cb9/ezpaging/images/pagination_next_dis.png", "Referer=http://bo.ezmall.vn/", "ENDITEM", 
		"Url=/zkau/web/ec1a8cb9/ezpaging/images/pagination_last_dis.png", "Referer=http://bo.ezmall.vn/", "ENDITEM", 
		"Url=/media/images/winpos.gif", "Referer=http://bo.ezmall.vn/", "ENDITEM", 
		"Url=/media/images/help_icon.png", "Referer=http://bo.ezmall.vn/", "ENDITEM", 
		"Url=/media/images/www.gif", "Referer=http://bo.ezmall.vn/", "ENDITEM", 
		"Url=/media/images/tab_android.gif", "Referer=http://bo.ezmall.vn/", "ENDITEM", 
		"Url=/media/images/iphone.gif", "Referer=http://bo.ezmall.vn/", "ENDITEM", 
		"Url=/media/images/ipad.png", "Referer=http://bo.ezmall.vn/", "ENDITEM", 
		"Url=/media/images/sodo_hethong_01.gif", "Referer=http://bo.ezmall.vn/", "ENDITEM", 
		"Url=/media/images/spacer.gif", "Referer=http://bo.ezmall.vn/", "ENDITEM", 
		"Url=/media/images/sodo_hethong_02.gif", "Referer=http://bo.ezmall.vn/", "ENDITEM", 
		"Url=/media/images/sodo_hethong_03.png", "Referer=http://bo.ezmall.vn/", "ENDITEM", 
		"Url=/media/images/sodo_hethong_05.png", "Referer=http://bo.ezmall.vn/", "ENDITEM", 
		"Url=/media/images/sodo_hethong_08.png", "Referer=http://bo.ezmall.vn/", "ENDITEM", 
		"Url=/media/images/sodo_hethong_10.png", "Referer=http://bo.ezmall.vn/", "ENDITEM", 
		"Url=/media/images/sodo_hethong_11.gif", "Referer=http://bo.ezmall.vn/", "ENDITEM", 
		"Url=/media/images/sodo_hethong_13.gif", "Referer=http://bo.ezmall.vn/", "ENDITEM", 
		"Url=/media/images/sodo_hethong_15.gif", "Referer=http://bo.ezmall.vn/", "ENDITEM", 
		"Url=/media/images/sodo_hethong_17.gif", "Referer=http://bo.ezmall.vn/", "ENDITEM", 
		"Url=/media/images/sodo_hethong_21.gif", "Referer=http://bo.ezmall.vn/", "ENDITEM", 
		"Url=/media/images/sodo_hethong_18.gif", "Referer=http://bo.ezmall.vn/", "ENDITEM", 
		"Url=/media/images/bg_content.gif", "Referer=http://bo.ezmall.vn/media/css/style_vi.css.dsp;jsessionid={JSESSIONID5}", "ENDITEM", 
		"Url=/media/images/blk_bg.gif", "Referer=http://bo.ezmall.vn/media/css/style_vi.css.dsp;jsessionid={JSESSIONID5}", "ENDITEM", 
		"Url=/media/images/yahoo.png", "Referer=http://bo.ezmall.vn/media/css/style_vi.css.dsp;jsessionid={JSESSIONID5}", "ENDITEM", 
		"Url=/media/images/support.png", "Referer=http://bo.ezmall.vn/media/css/style_vi.css.dsp;jsessionid={JSESSIONID5}", "ENDITEM", 
		"Url=/media/images/sky.png", "Referer=http://bo.ezmall.vn/media/css/style_vi.css.dsp;jsessionid={JSESSIONID5}", "ENDITEM", 
		"Url=/media/images/phone.png", "Referer=http://bo.ezmall.vn/media/css/style_vi.css.dsp;jsessionid={JSESSIONID5}", "ENDITEM", 
		"Url=/media/images/mail.png", "Referer=http://bo.ezmall.vn/media/css/style_vi.css.dsp;jsessionid={JSESSIONID5}", "ENDITEM", 
		"Url=/zkau/web/ec1a8cb9/sapphire/zul/img/tab/tab-corner.png", "Referer=http://bo.ezmall.vn/zkau/web/ec1a8cb9/_zkiju-sapphire/zul/css/zk.wcs;jsessionid={JSESSIONID5}", "ENDITEM", 
		"Url=/zkau/web/ec1a8cb9/sapphire/zul/img/tab/tab-hm.png", "Referer=http://bo.ezmall.vn/zkau/web/ec1a8cb9/_zkiju-sapphire/zul/css/zk.wcs;jsessionid={JSESSIONID5}", "ENDITEM", 
		"Url=/zkau/web/ec1a8cb9/sapphire/zul/img/input/datebtn.gif", "Referer=http://bo.ezmall.vn/zkau/web/ec1a8cb9/_zkiju-sapphire/zul/css/zk.wcs;jsessionid={JSESSIONID5}", "ENDITEM", 
		"Url=/zkau/web/ec1a8cb9/sapphire/zul/img/grid/column-bg.png", "Referer=http://bo.ezmall.vn/zkau/web/ec1a8cb9/_zkiju-sapphire/zul/css/zk.wcs;jsessionid={JSESSIONID5}", "ENDITEM", 
		"Url=/zkau/web/ec1a8cb9/zul/img/grid/row-expand.png", "Referer=http://bo.ezmall.vn/zkau/web/ec1a8cb9/_zkiju-sapphire/zul/css/zk.wcs;jsessionid={JSESSIONID5}", "ENDITEM", 
		"Url=/media/images/Centigrade-Widget-Icons/Bullet-10x10.png", "Referer=http://bo.ezmall.vn/media/css/ezstore.css.dsp;jsessionid={JSESSIONID5}", "ENDITEM", 
		"Url=/media/images/breeze-category-bg.png", "Referer=http://bo.ezmall.vn/media/css/ezstore.css.dsp;jsessionid={JSESSIONID5}", "ENDITEM", 
		"LAST");

	lr_end_transaction("duy_tan_trans",2);

	lr_think_time(3);

	return 0;
}
# 6 "e:\\scripts hp loadrunner\\07_08_2012\\bo.ezmall.vn\\scripts\\them_sua_xoa_hanghoa_of_cua_hang_web_http\\\\combined_Them_Sua_Xoa_hangHoa_of_cua_hang_WEB_HTTP.c" 2

# 1 "Cua_hang.c" 1
Cua_hang()
{

	lr_start_transaction("Cua_hang_trans");

	lr_think_time(28);

	web_submit_data("zkau;jsessionid=030641C2F7D86A1D23CAD254708552D6_3", 
		"Action=http://bo.ezmall.vn/zkau;jsessionid={JSESSIONID5}", 
		"Method=POST", 
		"RecContentType=text/plain", 
		"Referer=http://bo.ezmall.vn/", 
		"Snapshot=t5.inf", 
		"Mode=HTML", 
		"ITEMDATA", 
		"Name=dtid", "Value=Desktop_29", "ENDITEM", 
		"Name=cmd_0", "Value=onAnchorPos", "ENDITEM", 
		"Name=uuid_0", "Value=Listbox_1", "ENDITEM", 
		"Name=data_0", "Value={\"top\":-1,\"left\":-1}", "ENDITEM", 
		"Name=cmd_1", "Value=onClick", "ENDITEM", 
		"Name=uuid_1", "Value=Button_4", "ENDITEM", 
		"Name=data_1", "Value={\"pageX\":223,\"pageY\":102,\"which\":1,\"x\":46,\"y\":45}", "ENDITEM", 
		"EXTRARES", 
		"Url=/zkau/web/ec1a8cb9/ezpaging/images/pagination_next.png", "Referer=http://bo.ezmall.vn/", "ENDITEM", 
		"Url=/zkau/web/ec1a8cb9/ezpaging/images/pagination_last.png", "Referer=http://bo.ezmall.vn/", "ENDITEM", 
		"Url=/media/images/IconTest/edit_icon22x22.png", "Referer=http://bo.ezmall.vn/", "ENDITEM", 
		"Url=/zkau/web/ec1a8cb9/sapphire/zul/img/layout/borderlayout-hm.png", "Referer=http://bo.ezmall.vn/zkau/web/ec1a8cb9/_zkiju-sapphire/zul/css/zk.wcs;jsessionid={JSESSIONID5}", "ENDITEM", 
		"LAST");

	lr_end_transaction("Cua_hang_trans",2);

	lr_think_time(3);

	return 0;
}
# 7 "e:\\scripts hp loadrunner\\07_08_2012\\bo.ezmall.vn\\scripts\\them_sua_xoa_hanghoa_of_cua_hang_web_http\\\\combined_Them_Sua_Xoa_hangHoa_of_cua_hang_WEB_HTTP.c" 2

# 1 "Them_moi_hang_hoa.c" 1
Them_moi_hang_hoa()
{

	lr_start_transaction("Them_moi_hang_hoa_trans");

	lr_think_time(32);

	web_submit_data("zkau;jsessionid=030641C2F7D86A1D23CAD254708552D6_4", 
		"Action=http://bo.ezmall.vn/zkau;jsessionid={JSESSIONID5}", 
		"Method=POST", 
		"RecContentType=text/plain", 
		"Referer=http://bo.ezmall.vn/", 
		"Snapshot=t6.inf", 
		"Mode=HTML", 
		"ITEMDATA", 
		"Name=dtid", "Value=Desktop_29", "ENDITEM", 
		"Name=cmd_0", "Value=onClick", "ENDITEM", 
		"Name=uuid_0", "Value=Label_24", "ENDITEM", 
		"Name=data_0", "Value={\"pageX\":352,\"pageY\":187,\"which\":1,\"x\":40,\"y\":17}", "ENDITEM", 
		"EXTRARES", 
		"Url=/zkau/web/_zv2013032614/js/zul.utl.wpd;jsessionid={JSESSIONID5}", "Referer=http://bo.ezmall.vn/", "ENDITEM", 
		"Url=/media/images/IconTest/delete_btn_28x28.png", "Referer=http://bo.ezmall.vn/", "ENDITEM", 
		"Url=/zkau/web/ec1a8cb9/img/spacer.gif", "Referer=http://bo.ezmall.vn/", "ENDITEM", 
		"Url=/media/images/256x256/upload_128x128.png", "Referer=http://bo.ezmall.vn/", "ENDITEM", 
		"Url=/media/images/IconTest/add_button_28x28.png", "Referer=http://bo.ezmall.vn/", "ENDITEM", 
		"Url=/zkau/web/ec1a8cb9/sapphire/zul/img/wnd/wnd-icon.png", "Referer=http://bo.ezmall.vn/zkau/web/ec1a8cb9/_zkiju-sapphire/zul/css/zk.wcs;jsessionid={JSESSIONID5}", "ENDITEM", 
		"LAST");

	lr_think_time(33);

	web_custom_request("zkau;jsessionid=030641C2F7D86A1D23CAD254708552D6_5", 
		"URL=http://bo.ezmall.vn/zkau;jsessionid={JSESSIONID5}", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=http://bo.ezmall.vn/", 
		"Snapshot=t7.inf", 
		"Mode=HTML", 
		"EncType=application/x-www-form-urlencoded;charset=UTF-8", 
		"Body=dtid=Desktop_29&cmd_0=onMove&opt_0=i&uuid_0=Listitem_1&data_0=%7B%22left%22%3A%22284px%22%2C%22top%22%3A%222px%22%7D&cmd_1=onZIndex&opt_1=i&uuid_1=Listitem_1&data_1=%7B%22%22%3A1800%7D&cmd_2=onChange&uuid_2=Hbox_9&data_2=%7B%22value%22%3A%222345678904566%22%2C%22start%22%3A13%7D&cmd_3=onChange&uuid_3=Column_2&data_3=%7B%22value%22%3A%22Qu%E1%BA%A7n%20%E1%BA%A4u%22%2C%22start%22%3A7%7D&cmd_4=onChange&uuid_4=Hbox_10&data_4=%7B%22value%22%3A%221%22%2C%22start%22%3A1%7D&cmd_5=onBlur&uuid_5=Hbox_10", 
		"LAST");

	web_submit_data("zkau;jsessionid=030641C2F7D86A1D23CAD254708552D6_6", 
		"Action=http://bo.ezmall.vn/zkau;jsessionid={JSESSIONID5}", 
		"Method=POST", 
		"RecContentType=text/plain", 
		"Referer=http://bo.ezmall.vn/", 
		"Snapshot=t8.inf", 
		"Mode=HTML", 
		"ITEMDATA", 
		"Name=dtid", "Value=Desktop_29", "ENDITEM", 
		"Name=cmd_0", "Value=onChange", "ENDITEM", 
		"Name=uuid_0", "Value=Hbox_10", "ENDITEM", 
		"Name=data_0", "Value={\"value\":\"17\",\"start\":2}", "ENDITEM", 
		"Name=cmd_1", "Value=onBlur", "ENDITEM", 
		"Name=uuid_1", "Value=Hbox_10", "ENDITEM", 
		"LAST");

	web_submit_data("zkau;jsessionid=030641C2F7D86A1D23CAD254708552D6_7", 
		"Action=http://bo.ezmall.vn/zkau;jsessionid={JSESSIONID5}", 
		"Method=POST", 
		"RecContentType=text/plain", 
		"Referer=http://bo.ezmall.vn/", 
		"Snapshot=t9.inf", 
		"Mode=HTML", 
		"ITEMDATA", 
		"Name=dtid", "Value=Desktop_29", "ENDITEM", 
		"Name=cmd_0", "Value=onChange", "ENDITEM", 
		"Name=uuid_0", "Value=Hbox_10", "ENDITEM", 
		"Name=data_0", "Value={\"value\":\"170\",\"start\":3}", "ENDITEM", 
		"Name=cmd_1", "Value=onBlur", "ENDITEM", 
		"Name=uuid_1", "Value=Hbox_10", "ENDITEM", 
		"LAST");

	web_submit_data("zkau;jsessionid=030641C2F7D86A1D23CAD254708552D6_8", 
		"Action=http://bo.ezmall.vn/zkau;jsessionid={JSESSIONID5}", 
		"Method=POST", 
		"RecContentType=text/plain", 
		"Referer=http://bo.ezmall.vn/", 
		"Snapshot=t10.inf", 
		"Mode=HTML", 
		"ITEMDATA", 
		"Name=dtid", "Value=Desktop_29", "ENDITEM", 
		"Name=cmd_0", "Value=onChange", "ENDITEM", 
		"Name=uuid_0", "Value=Hbox_10", "ENDITEM", 
		"Name=data_0", "Value={\"value\":\"1700\",\"start\":4}", "ENDITEM", 
		"Name=cmd_1", "Value=onBlur", "ENDITEM", 
		"Name=uuid_1", "Value=Hbox_10", "ENDITEM", 
		"LAST");

	web_submit_data("zkau;jsessionid=030641C2F7D86A1D23CAD254708552D6_9", 
		"Action=http://bo.ezmall.vn/zkau;jsessionid={JSESSIONID5}", 
		"Method=POST", 
		"RecContentType=text/plain", 
		"Referer=http://bo.ezmall.vn/", 
		"Snapshot=t11.inf", 
		"Mode=HTML", 
		"ITEMDATA", 
		"Name=dtid", "Value=Desktop_29", "ENDITEM", 
		"Name=cmd_0", "Value=onChange", "ENDITEM", 
		"Name=uuid_0", "Value=Hbox_10", "ENDITEM", 
		"Name=data_0", "Value={\"value\":\"1.7000\",\"start\":6}", "ENDITEM", 
		"Name=cmd_1", "Value=onBlur", "ENDITEM", 
		"Name=uuid_1", "Value=Hbox_10", "ENDITEM", 
		"LAST");

	web_submit_data("zkau;jsessionid=030641C2F7D86A1D23CAD254708552D6_10", 
		"Action=http://bo.ezmall.vn/zkau;jsessionid={JSESSIONID5}", 
		"Method=POST", 
		"RecContentType=text/plain", 
		"Referer=http://bo.ezmall.vn/", 
		"Snapshot=t12.inf", 
		"Mode=HTML", 
		"ITEMDATA", 
		"Name=dtid", "Value=Desktop_29", "ENDITEM", 
		"Name=cmd_0", "Value=onChange", "ENDITEM", 
		"Name=uuid_0", "Value=Hbox_10", "ENDITEM", 
		"Name=data_0", "Value={\"value\":\"17.0000\",\"start\":7}", "ENDITEM", 
		"Name=cmd_1", "Value=onBlur", "ENDITEM", 
		"Name=uuid_1", "Value=Hbox_10", "ENDITEM", 
		"LAST");

	web_submit_data("zkau;jsessionid=030641C2F7D86A1D23CAD254708552D6_11", 
		"Action=http://bo.ezmall.vn/zkau;jsessionid={JSESSIONID5}", 
		"Method=POST", 
		"RecContentType=text/plain", 
		"Referer=http://bo.ezmall.vn/", 
		"Snapshot=t13.inf", 
		"Mode=HTML", 
		"ITEMDATA", 
		"Name=dtid", "Value=Desktop_29", "ENDITEM", 
		"Name=cmd_0", "Value=onBlur", "ENDITEM", 
		"Name=uuid_0", "Value=Hbox_10", "ENDITEM", 
		"LAST");

	lr_think_time(5);

	web_submit_data("zkau;jsessionid=030641C2F7D86A1D23CAD254708552D6_12", 
		"Action=http://bo.ezmall.vn/zkau;jsessionid={JSESSIONID5}", 
		"Method=POST", 
		"RecContentType=text/plain", 
		"Referer=http://bo.ezmall.vn/", 
		"Snapshot=t14.inf", 
		"Mode=HTML", 
		"ITEMDATA", 
		"Name=dtid", "Value=Desktop_29", "ENDITEM", 
		"Name=cmd_0", "Value=onBlur", "ENDITEM", 
		"Name=uuid_0", "Value=Hbox_10", "ENDITEM", 
		"LAST");

	lr_think_time(10);

	web_submit_data("zkau;jsessionid=030641C2F7D86A1D23CAD254708552D6_13", 
		"Action=http://bo.ezmall.vn/zkau;jsessionid={JSESSIONID5}", 
		"Method=POST", 
		"RecContentType=text/plain", 
		"Referer=http://bo.ezmall.vn/", 
		"Snapshot=t15.inf", 
		"Mode=HTML", 
		"ITEMDATA", 
		"Name=dtid", "Value=Desktop_29", "ENDITEM", 
		"Name=cmd_0", "Value=onChange", "ENDITEM", 
		"Name=uuid_0", "Value=Label_34", "ENDITEM", 
		"Name=data_0", "Value={\"value\":\"Quần\",\"start\":0}", "ENDITEM", 
		"Name=cmd_1", "Value=onSelect", "ENDITEM", 
		"Name=uuid_1", "Value=Label_34", "ENDITEM", 
		"Name=data_1", "Value={\"items\":[\"Label_14\"],\"reference\":\"Label_14\"}", "ENDITEM", 
		"Name=cmd_2", "Value=onClick", "ENDITEM", 
		"Name=uuid_2", "Value=Radiogroup_1", "ENDITEM", 
		"Name=data_2", "Value={\"pageX\":886,\"pageY\":167,\"which\":1,\"x\":28.20001220703125,\"y\":13}", "ENDITEM", 
		"LAST");

	lr_think_time(8);

	web_submit_data("zkau;jsessionid=030641C2F7D86A1D23CAD254708552D6_14", 
		"Action=http://bo.ezmall.vn/zkau;jsessionid={JSESSIONID5}", 
		"Method=POST", 
		"RecContentType=text/plain", 
		"Referer=http://bo.ezmall.vn/", 
		"Snapshot=t16.inf", 
		"Mode=HTML", 
		"ITEMDATA", 
		"Name=dtid", "Value=Desktop_29", "ENDITEM", 
		"Name=cmd_0", "Value=onFocus", "ENDITEM", 
		"Name=uuid_0", "Value=Listitem_4", "ENDITEM", 
		"LAST");

	lr_think_time(9);

	web_custom_request("zkau;jsessionid=030641C2F7D86A1D23CAD254708552D6_15", 
		"URL=http://bo.ezmall.vn/zkau;jsessionid={JSESSIONID5}", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=http://bo.ezmall.vn/", 
		"Snapshot=t17.inf", 
		"Mode=HTML", 
		"EncType=application/x-www-form-urlencoded;charset=UTF-8", 
		"Body=dtid=Desktop_29&cmd_0=onChange&uuid_0=Listitem_4&data_0=%7B%22value%22%3A%22Qu%E1%BA%A7n%20%C3%81o%20C%C3%B4ng%20S%E1%BB%9F%22%2C%22start%22%3A15%7D&cmd_1=onBlur&uuid_1=Listitem_4", 
		"LAST");

	web_submit_data("zkau;jsessionid=030641C2F7D86A1D23CAD254708552D6_16", 
		"Action=http://bo.ezmall.vn/zkau;jsessionid={JSESSIONID5}", 
		"Method=POST", 
		"RecContentType=text/plain", 
		"Referer=http://bo.ezmall.vn/", 
		"Snapshot=t18.inf", 
		"Mode=HTML", 
		"ITEMDATA", 
		"Name=dtid", "Value=Desktop_29", "ENDITEM", 
		"Name=cmd_0", "Value=onClick", "ENDITEM", 
		"Name=uuid_0", "Value=Listcell_3", "ENDITEM", 
		"Name=data_0", "Value={\"pageX\":882,\"pageY\":208,\"which\":1,\"x\":35.5999755859375,\"y\":15}", "ENDITEM", 
		"LAST");

	web_submit_data("zkau;jsessionid=030641C2F7D86A1D23CAD254708552D6_17", 
		"Action=http://bo.ezmall.vn/zkau;jsessionid={JSESSIONID5}", 
		"Method=POST", 
		"RecContentType=text/plain", 
		"Referer=http://bo.ezmall.vn/", 
		"Snapshot=t19.inf", 
		"Mode=HTML", 
		"ITEMDATA", 
		"Name=dtid", "Value=Desktop_29", "ENDITEM", 
		"Name=cmd_0", "Value=onChange", "ENDITEM", 
		"Name=uuid_0", "Value=Columns_2", "ENDITEM", 
		"Name=data_0", "Value={\"value\":\"1\",\"start\":1}", "ENDITEM", 
		"Name=cmd_1", "Value=onBlur", "ENDITEM", 
		"Name=uuid_1", "Value=Columns_2", "ENDITEM", 
		"LAST");

	web_submit_data("zkau;jsessionid=030641C2F7D86A1D23CAD254708552D6_18", 
		"Action=http://bo.ezmall.vn/zkau;jsessionid={JSESSIONID5}", 
		"Method=POST", 
		"RecContentType=text/plain", 
		"Referer=http://bo.ezmall.vn/", 
		"Snapshot=t20.inf", 
		"Mode=HTML", 
		"ITEMDATA", 
		"Name=dtid", "Value=Desktop_29", "ENDITEM", 
		"Name=cmd_0", "Value=onChange", "ENDITEM", 
		"Name=uuid_0", "Value=Columns_2", "ENDITEM", 
		"Name=data_0", "Value={\"value\":\"11\",\"start\":2}", "ENDITEM", 
		"Name=cmd_1", "Value=onBlur", "ENDITEM", 
		"Name=uuid_1", "Value=Columns_2", "ENDITEM", 
		"LAST");

	web_submit_data("zkau;jsessionid=030641C2F7D86A1D23CAD254708552D6_19", 
		"Action=http://bo.ezmall.vn/zkau;jsessionid={JSESSIONID5}", 
		"Method=POST", 
		"RecContentType=text/plain", 
		"Referer=http://bo.ezmall.vn/", 
		"Snapshot=t21.inf", 
		"Mode=HTML", 
		"ITEMDATA", 
		"Name=dtid", "Value=Desktop_29", "ENDITEM", 
		"Name=cmd_0", "Value=onChange", "ENDITEM", 
		"Name=uuid_0", "Value=Columns_2", "ENDITEM", 
		"Name=data_0", "Value={\"value\":\"110\",\"start\":3}", "ENDITEM", 
		"Name=cmd_1", "Value=onBlur", "ENDITEM", 
		"Name=uuid_1", "Value=Columns_2", "ENDITEM", 
		"LAST");

	web_submit_data("zkau;jsessionid=030641C2F7D86A1D23CAD254708552D6_20", 
		"Action=http://bo.ezmall.vn/zkau;jsessionid={JSESSIONID5}", 
		"Method=POST", 
		"RecContentType=text/plain", 
		"Referer=http://bo.ezmall.vn/", 
		"Snapshot=t22.inf", 
		"Mode=HTML", 
		"ITEMDATA", 
		"Name=dtid", "Value=Desktop_29", "ENDITEM", 
		"Name=cmd_0", "Value=onChange", "ENDITEM", 
		"Name=uuid_0", "Value=Columns_2", "ENDITEM", 
		"Name=data_0", "Value={\"value\":\"1100\",\"start\":4}", "ENDITEM", 
		"Name=cmd_1", "Value=onBlur", "ENDITEM", 
		"Name=uuid_1", "Value=Columns_2", "ENDITEM", 
		"LAST");

	web_submit_data("zkau;jsessionid=030641C2F7D86A1D23CAD254708552D6_21", 
		"Action=http://bo.ezmall.vn/zkau;jsessionid={JSESSIONID5}", 
		"Method=POST", 
		"RecContentType=text/plain", 
		"Referer=http://bo.ezmall.vn/", 
		"Snapshot=t23.inf", 
		"Mode=HTML", 
		"ITEMDATA", 
		"Name=dtid", "Value=Desktop_29", "ENDITEM", 
		"Name=cmd_0", "Value=onChange", "ENDITEM", 
		"Name=uuid_0", "Value=Columns_2", "ENDITEM", 
		"Name=data_0", "Value={\"value\":\"1.1000\",\"start\":6}", "ENDITEM", 
		"Name=cmd_1", "Value=onBlur", "ENDITEM", 
		"Name=uuid_1", "Value=Columns_2", "ENDITEM", 
		"LAST");

	web_submit_data("zkau;jsessionid=030641C2F7D86A1D23CAD254708552D6_22", 
		"Action=http://bo.ezmall.vn/zkau;jsessionid={JSESSIONID5}", 
		"Method=POST", 
		"RecContentType=text/plain", 
		"Referer=http://bo.ezmall.vn/", 
		"Snapshot=t24.inf", 
		"Mode=HTML", 
		"ITEMDATA", 
		"Name=dtid", "Value=Desktop_29", "ENDITEM", 
		"Name=cmd_0", "Value=onChange", "ENDITEM", 
		"Name=uuid_0", "Value=Columns_2", "ENDITEM", 
		"Name=data_0", "Value={\"value\":\"11.0000\",\"start\":7}", "ENDITEM", 
		"Name=cmd_1", "Value=onBlur", "ENDITEM", 
		"Name=uuid_1", "Value=Columns_2", "ENDITEM", 
		"LAST");

	web_submit_data("zkau;jsessionid=030641C2F7D86A1D23CAD254708552D6_23", 
		"Action=http://bo.ezmall.vn/zkau;jsessionid={JSESSIONID5}", 
		"Method=POST", 
		"RecContentType=text/plain", 
		"Referer=http://bo.ezmall.vn/", 
		"Snapshot=t25.inf", 
		"Mode=HTML", 
		"ITEMDATA", 
		"Name=dtid", "Value=Desktop_29", "ENDITEM", 
		"Name=cmd_0", "Value=onBlur", "ENDITEM", 
		"Name=uuid_0", "Value=Columns_2", "ENDITEM", 
		"LAST");

	web_submit_data("zkau;jsessionid=030641C2F7D86A1D23CAD254708552D6_24", 
		"Action=http://bo.ezmall.vn/zkau;jsessionid={JSESSIONID5}", 
		"Method=POST", 
		"RecContentType=text/plain", 
		"Referer=http://bo.ezmall.vn/", 
		"Snapshot=t26.inf", 
		"Mode=HTML", 
		"ITEMDATA", 
		"Name=dtid", "Value=Desktop_29", "ENDITEM", 
		"Name=cmd_0", "Value=onClick", "ENDITEM", 
		"Name=uuid_0", "Value=Label_101", "ENDITEM", 
		"Name=data_0", "Value={\"pageX\":565,\"pageY\":518,\"which\":1,\"x\":49.5,\"y\":20}", "ENDITEM", 
		"LAST");

	web_submit_data("zkau;jsessionid=030641C2F7D86A1D23CAD254708552D6_25", 
		"Action=http://bo.ezmall.vn/zkau;jsessionid={JSESSIONID5}", 
		"Method=POST", 
		"RecContentType=text/plain", 
		"Referer=http://bo.ezmall.vn/", 
		"Snapshot=t27.inf", 
		"Mode=HTML", 
		"ITEMDATA", 
		"Name=dtid", "Value=Desktop_29", "ENDITEM", 
		"Name=cmd_0", "Value=onClick", "ENDITEM", 
		"Name=uuid_0", "Value=Label_101", "ENDITEM", 
		"Name=data_0", "Value={\"pageX\":565,\"pageY\":518,\"which\":1,\"x\":49.5,\"y\":20}", "ENDITEM", 
		"EXTRARES", 
		"Url=/zkau/web/ec1a8cb9/sapphire/zul/img/button/toolbarbtn-ctr.gif", "Referer=http://bo.ezmall.vn/zkau/web/ec1a8cb9/_zkiju-sapphire/zul/css/zk.wcs;jsessionid={JSESSIONID5}", "ENDITEM", 
		"LAST");

	lr_end_transaction("Them_moi_hang_hoa_trans",2);

	lr_think_time(3);

	return 0;
}
# 8 "e:\\scripts hp loadrunner\\07_08_2012\\bo.ezmall.vn\\scripts\\them_sua_xoa_hanghoa_of_cua_hang_web_http\\\\combined_Them_Sua_Xoa_hangHoa_of_cua_hang_WEB_HTTP.c" 2

# 1 "Sua_sanPham_CafeTrung_nguyen.c" 1
Sua_sanPham_CafeTrung_nguyen()
{

	lr_start_transaction("Sua_sanPham_CafeTrung_nguyen");

	lr_think_time(54);

	web_submit_data("zkau;jsessionid=030641C2F7D86A1D23CAD254708552D6_26", 
		"Action=http://bo.ezmall.vn/zkau;jsessionid={JSESSIONID5}", 
		"Method=POST", 
		"RecContentType=text/plain", 
		"Referer=http://bo.ezmall.vn/", 
		"Snapshot=t28.inf", 
		"Mode=HTML", 
		"ITEMDATA", 
		"Name=dtid", "Value=Desktop_29", "ENDITEM", 
		"Name=cmd_0", "Value=onClick", "ENDITEM", 
		"Name=uuid_0", "Value=Label_602", "ENDITEM", 
		"Name=data_0", "Value={\"pageX\":371,\"pageY\":352,\"which\":1,\"x\":13,\"y\":12}", "ENDITEM", 
		"EXTRARES", 
		"Url=/zkau/view/Desktop_29/Label_541/fg41/1/c/a.png", "Referer=http://bo.ezmall.vn/", "ENDITEM", 
		"LAST");

	lr_think_time(12);

	web_custom_request("zkau;jsessionid=030641C2F7D86A1D23CAD254708552D6_27", 
		"URL=http://bo.ezmall.vn/zkau;jsessionid={JSESSIONID5}", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=http://bo.ezmall.vn/", 
		"Snapshot=t29.inf", 
		"Mode=HTML", 
		"EncType=application/x-www-form-urlencoded;charset=UTF-8", 
		"Body=dtid=Desktop_29&cmd_0=onMove&opt_0=i&uuid_0=Label_561&data_0=%7B%22left%22%3A%22284px%22%2C%22top%22%3A%222px%22%7D&cmd_1=onZIndex&opt_1=i&uuid_1=Label_561&data_1=%7B%22%22%3A1800%7D&cmd_2=onChange&uuid_2=Label_928&data_2=%7B%22value%22%3A%22Cafe%20Trung%20Nguy%C3%AAn%20G9%22%2C%22start%22%3A20%7D&cmd_3=onChange&uuid_3=Tabbox_1&data_3=%7B%22value%22%3A%2245.000%22%2C%22start%22%3A1%7D&cmd_4=onBlur&uuid_4=Tabbox_1", 
		"LAST");

	web_submit_data("zkau;jsessionid=030641C2F7D86A1D23CAD254708552D6_28", 
		"Action=http://bo.ezmall.vn/zkau;jsessionid={JSESSIONID5}", 
		"Method=POST", 
		"RecContentType=text/plain", 
		"Referer=http://bo.ezmall.vn/", 
		"Snapshot=t30.inf", 
		"Mode=HTML", 
		"ITEMDATA", 
		"Name=dtid", "Value=Desktop_29", "ENDITEM", 
		"Name=cmd_0", "Value=onBlur", "ENDITEM", 
		"Name=uuid_0", "Value=Tabbox_1", "ENDITEM", 
		"LAST");

	lr_think_time(5);

	web_submit_data("zkau;jsessionid=030641C2F7D86A1D23CAD254708552D6_29", 
		"Action=http://bo.ezmall.vn/zkau;jsessionid={JSESSIONID5}", 
		"Method=POST", 
		"RecContentType=text/plain", 
		"Referer=http://bo.ezmall.vn/", 
		"Snapshot=t31.inf", 
		"Mode=HTML", 
		"ITEMDATA", 
		"Name=dtid", "Value=Desktop_29", "ENDITEM", 
		"Name=cmd_0", "Value=onChange", "ENDITEM", 
		"Name=uuid_0", "Value=Html_6", "ENDITEM", 
		"Name=data_0", "Value={\"value\":\"3.000\",\"start\":1}", "ENDITEM", 
		"Name=cmd_1", "Value=onBlur", "ENDITEM", 
		"Name=uuid_1", "Value=Html_6", "ENDITEM", 
		"LAST");

	web_submit_data("zkau;jsessionid=030641C2F7D86A1D23CAD254708552D6_30", 
		"Action=http://bo.ezmall.vn/zkau;jsessionid={JSESSIONID5}", 
		"Method=POST", 
		"RecContentType=text/plain", 
		"Referer=http://bo.ezmall.vn/", 
		"Snapshot=t32.inf", 
		"Mode=HTML", 
		"ITEMDATA", 
		"Name=dtid", "Value=Desktop_29", "ENDITEM", 
		"Name=cmd_0", "Value=onChange", "ENDITEM", 
		"Name=uuid_0", "Value=Html_6", "ENDITEM", 
		"Name=data_0", "Value={\"value\":\"35.000\",\"start\":2}", "ENDITEM", 
		"Name=cmd_1", "Value=onBlur", "ENDITEM", 
		"Name=uuid_1", "Value=Html_6", "ENDITEM", 
		"LAST");

	web_submit_data("zkau;jsessionid=030641C2F7D86A1D23CAD254708552D6_31", 
		"Action=http://bo.ezmall.vn/zkau;jsessionid={JSESSIONID5}", 
		"Method=POST", 
		"RecContentType=text/plain", 
		"Referer=http://bo.ezmall.vn/", 
		"Snapshot=t33.inf", 
		"Mode=HTML", 
		"ITEMDATA", 
		"Name=dtid", "Value=Desktop_29", "ENDITEM", 
		"Name=cmd_0", "Value=onBlur", "ENDITEM", 
		"Name=uuid_0", "Value=Html_6", "ENDITEM", 
		"LAST");

	web_submit_data("zkau;jsessionid=030641C2F7D86A1D23CAD254708552D6_32", 
		"Action=http://bo.ezmall.vn/zkau;jsessionid={JSESSIONID5}", 
		"Method=POST", 
		"RecContentType=text/plain", 
		"Referer=http://bo.ezmall.vn/", 
		"Snapshot=t34.inf", 
		"Mode=HTML", 
		"ITEMDATA", 
		"Name=dtid", "Value=Desktop_29", "ENDITEM", 
		"Name=cmd_0", "Value=onClick", "ENDITEM", 
		"Name=uuid_0", "Value=Label_694", "ENDITEM", 
		"Name=data_0", "Value={\"pageX\":574,\"pageY\":511,\"which\":1,\"x\":58.5,\"y\":13}", "ENDITEM", 
		"LAST");

	lr_end_transaction("Sua_sanPham_CafeTrung_nguyen",2);

	lr_think_time(3);

	return 0;
}
# 9 "e:\\scripts hp loadrunner\\07_08_2012\\bo.ezmall.vn\\scripts\\them_sua_xoa_hanghoa_of_cua_hang_web_http\\\\combined_Them_Sua_Xoa_hangHoa_of_cua_hang_WEB_HTTP.c" 2

# 1 "Xoa_sanPham_Quanau.c" 1
Xoa_sanPham_Quanau()
{

	lr_start_transaction("Xoa_sanPham_Quanau_trans");

	lr_think_time(42);

	web_submit_data("zkau;jsessionid=030641C2F7D86A1D23CAD254708552D6_33", 
		"Action=http://bo.ezmall.vn/zkau;jsessionid={JSESSIONID5}", 
		"Method=POST", 
		"RecContentType=text/plain", 
		"Referer=http://bo.ezmall.vn/", 
		"Snapshot=t35.inf", 
		"Mode=HTML", 
		"ITEMDATA", 
		"Name=dtid", "Value=Desktop_29", "ENDITEM", 
		"Name=cmd_0", "Value=onClick", "ENDITEM", 
		"Name=uuid_0", "Value=Div_49", "ENDITEM", 
		"Name=data_0", "Value={\"pageX\":992,\"pageY\":179,\"which\":1,\"x\":16.79998779296875,\"y\":10}", "ENDITEM", 
		"EXTRARES", 
		"Url=/zkau/web/ec1a8cb9/ezpaging/images/pagination_first.png", "Referer=http://bo.ezmall.vn/", "ENDITEM", 
		"Url=/zkau/web/ec1a8cb9/ezpaging/images/pagination_prev.png", "Referer=http://bo.ezmall.vn/", "ENDITEM", 
		"LAST");

	web_submit_data("zkau;jsessionid=030641C2F7D86A1D23CAD254708552D6_34", 
		"Action=http://bo.ezmall.vn/zkau;jsessionid={JSESSIONID5}", 
		"Method=POST", 
		"RecContentType=text/plain", 
		"Referer=http://bo.ezmall.vn/", 
		"Snapshot=t36.inf", 
		"Mode=HTML", 
		"ITEMDATA", 
		"Name=dtid", "Value=Desktop_29", "ENDITEM", 
		"Name=cmd_0", "Value=onClick", "ENDITEM", 
		"Name=uuid_0", "Value=Div_49", "ENDITEM", 
		"Name=data_0", "Value={\"pageX\":984,\"pageY\":181,\"which\":1,\"x\":14.79998779296875,\"y\":12}", "ENDITEM", 
		"LAST");

	web_submit_data("zkau;jsessionid=030641C2F7D86A1D23CAD254708552D6_35", 
		"Action=http://bo.ezmall.vn/zkau;jsessionid={JSESSIONID5}", 
		"Method=POST", 
		"RecContentType=text/plain", 
		"Referer=http://bo.ezmall.vn/", 
		"Snapshot=t37.inf", 
		"Mode=HTML", 
		"ITEMDATA", 
		"Name=dtid", "Value=Desktop_29", "ENDITEM", 
		"Name=cmd_0", "Value=onClick", "ENDITEM", 
		"Name=uuid_0", "Value=Div_49", "ENDITEM", 
		"Name=data_0", "Value={\"pageX\":980,\"pageY\":178,\"which\":1,\"x\":11.79998779296875,\"y\":9}", "ENDITEM", 
		"EXTRARES", 
		"Url=/media/images/IconTest/delete_icon22x22.png", "Referer=http://bo.ezmall.vn/", "ENDITEM", 
		"LAST");

	web_submit_data("zkau;jsessionid=030641C2F7D86A1D23CAD254708552D6_36", 
		"Action=http://bo.ezmall.vn/zkau;jsessionid={JSESSIONID5}", 
		"Method=POST", 
		"RecContentType=text/plain", 
		"Referer=http://bo.ezmall.vn/", 
		"Snapshot=t38.inf", 
		"Mode=HTML", 
		"ITEMDATA", 
		"Name=dtid", "Value=Desktop_29", "ENDITEM", 
		"Name=cmd_0", "Value=onClick", "ENDITEM", 
		"Name=uuid_0", "Value=Div_49", "ENDITEM", 
		"Name=data_0", "Value={\"pageX\":980,\"pageY\":178,\"which\":1,\"x\":11.79998779296875,\"y\":9}", "ENDITEM", 
		"LAST");

	lr_think_time(4);

	web_submit_data("zkau;jsessionid=030641C2F7D86A1D23CAD254708552D6_37", 
		"Action=http://bo.ezmall.vn/zkau;jsessionid={JSESSIONID5}", 
		"Method=POST", 
		"RecContentType=text/plain", 
		"Referer=http://bo.ezmall.vn/", 
		"Snapshot=t39.inf", 
		"Mode=HTML", 
		"ITEMDATA", 
		"Name=dtid", "Value=Desktop_29", "ENDITEM", 
		"Name=cmd_0", "Value=onClick", "ENDITEM", 
		"Name=uuid_0", "Value=Comboitem_33", "ENDITEM", 
		"Name=data_0", "Value={\"pageX\":402,\"pageY\":352,\"which\":1,\"x\":14,\"y\":12}", "ENDITEM", 
		"EXTRARES", 
		"Url=/zkau/web/ec1a8cb9/sapphire/zul/img/msgbox/question-btn.png", "Referer=http://bo.ezmall.vn/zkau/web/ec1a8cb9/_zkiju-sapphire/zul/css/zk.wcs;jsessionid={JSESSIONID5}", "ENDITEM", 
		"LAST");

	web_submit_data("zkau;jsessionid=030641C2F7D86A1D23CAD254708552D6_38", 
		"Action=http://bo.ezmall.vn/zkau;jsessionid={JSESSIONID5}", 
		"Method=POST", 
		"RecContentType=text/plain", 
		"Referer=http://bo.ezmall.vn/", 
		"Snapshot=t40.inf", 
		"Mode=HTML", 
		"ITEMDATA", 
		"Name=dtid", "Value=Desktop_29", "ENDITEM", 
		"Name=cmd_0", "Value=onMove", "ENDITEM", 
		"Name=opt_0", "Value=i", "ENDITEM", 
		"Name=uuid_0", "Value=Comboitem_45", "ENDITEM", 
		"Name=data_0", "Value={\"left\":\"435px\",\"top\":\"100px\"}", "ENDITEM", 
		"Name=cmd_1", "Value=onZIndex", "ENDITEM", 
		"Name=opt_1", "Value=i", "ENDITEM", 
		"Name=uuid_1", "Value=Comboitem_45", "ENDITEM", 
		"Name=data_1", "Value={\"\":1800}", "ENDITEM", 
		"Name=cmd_2", "Value=onClick", "ENDITEM", 
		"Name=uuid_2", "Value=Label_150", "ENDITEM", 
		"Name=data_2", "Value={\"pageX\":588,\"pageY\":216,\"which\":1,\"x\":56.29998779296875,\"y\":19}", "ENDITEM", 
		"LAST");

	lr_end_transaction("Xoa_sanPham_Quanau_trans",2);

	lr_think_time(3);

	return 0;
}
# 10 "e:\\scripts hp loadrunner\\07_08_2012\\bo.ezmall.vn\\scripts\\them_sua_xoa_hanghoa_of_cua_hang_web_http\\\\combined_Them_Sua_Xoa_hangHoa_of_cua_hang_WEB_HTTP.c" 2

# 1 "dang_xuat.c" 1
dang_xuat()
{

	lr_start_transaction("dang_xuat");

	lr_think_time(23);

	web_submit_data("zkau;jsessionid=030641C2F7D86A1D23CAD254708552D6_39", 
		"Action=http://bo.ezmall.vn/zkau;jsessionid={JSESSIONID5}", 
		"Method=POST", 
		"RecContentType=text/plain", 
		"Referer=http://bo.ezmall.vn/", 
		"Snapshot=t41.inf", 
		"Mode=HTML", 
		"ITEMDATA", 
		"Name=dtid", "Value=Desktop_29", "ENDITEM", 
		"Name=cmd_0", "Value=onClick", "ENDITEM", 
		"Name=uuid_0", "Value=Button_2", "ENDITEM", 
		"Name=data_0", "Value={\"pageX\":1071,\"pageY\":25,\"which\":1,\"x\":28,\"y\":12}", "ENDITEM", 
		"LAST");

	web_url("bo.ezmall.vn_2", 
		"URL=http://bo.ezmall.vn/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://bo.ezmall.vn/", 
		"Snapshot=t42.inf", 
		"Mode=HTML", 
		"EXTRARES", 
		"Url=/zkau/web/_zv2013032614/js/zul.layout.wpd", "ENDITEM", 
		"Url=/zkau/web/_zv2013032614/js/zul.box.wpd", "ENDITEM", 
		"Url=/zkau/web/_zv2013032614/js/zul.wnd.wpd", "ENDITEM", 
		"Url=/zkau/web/_zv2013032614/js/zul.inp.wpd", "ENDITEM", 
		"Url=/zkau/web/_zv2013032614/js/zul.sel.wpd", "ENDITEM", 
		"Url=/zkau/web/_zv2013032614/js/zk.fmt.wpd", "ENDITEM", 
		"Url=/zkau/web/_zv2013032614/js/zul.mesh.wpd", "ENDITEM", 
		"Url=/zkau/web/_zv2013032614/js/zul.menu.wpd", "ENDITEM", 
		"Url=/media/images/icon_header/location_icon_16x21.png", "ENDITEM", 
		"Url=/media/images/IconTest/maybanhang_logo_251x44.png", "ENDITEM", 
		"Url=/media/images/icon_header/support_icon_25x25.png", "ENDITEM", 
		"Url=/media/images/icon_header/cuahang52x52.png", "ENDITEM", 
		"Url=/media/images/icon_header/dashboard52x52.png", "ENDITEM", 
		"Url=/media/images/vi.png", "ENDITEM", 
		"Url=/media/images/icon_header/khachhang52x52.png", "ENDITEM", 
		"Url=/media/images/icon_header/khohang52x52.png", "ENDITEM", 
		"Url=/media/images/icon_header/order52x52.png", "ENDITEM", 
		"Url=/media/images/icon_header/invoice52x52.png", "ENDITEM", 
		"Url=/media/images/icon_header/cash52x52.png", "ENDITEM", 
		"Url=/media/images/icon_header/baocao52x52.png", "ENDITEM", 
		"Url=/media/images/icon_header/email52x52.png", "ENDITEM", 
		"Url=/media/images/icon_header/setting52x52.png", "ENDITEM", 
		"Url=/media/images/icon_header/taikhoan52x52.png", "ENDITEM", 
		"Url=/media/images/icon_header/nhanvien52x52.png", "ENDITEM", 
		"Url=/media/images/icon_header/support52x52.png", "ENDITEM", 
		"LAST");

	lr_end_transaction("dang_xuat",2);

	lr_think_time(3);

	return 0;
}
# 11 "e:\\scripts hp loadrunner\\07_08_2012\\bo.ezmall.vn\\scripts\\them_sua_xoa_hanghoa_of_cua_hang_web_http\\\\combined_Them_Sua_Xoa_hangHoa_of_cua_hang_WEB_HTTP.c" 2

# 1 "vuser_end.c" 1
vuser_end()
{
	return 0;
}
# 12 "e:\\scripts hp loadrunner\\07_08_2012\\bo.ezmall.vn\\scripts\\them_sua_xoa_hanghoa_of_cua_hang_web_http\\\\combined_Them_Sua_Xoa_hangHoa_of_cua_hang_WEB_HTTP.c" 2

