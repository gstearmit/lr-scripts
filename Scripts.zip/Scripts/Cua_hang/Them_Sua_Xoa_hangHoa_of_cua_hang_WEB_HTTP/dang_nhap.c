dang_nhap()
{

	lr_start_transaction("dang_nhap_tran");

	lr_think_time(51);

	web_submit_data("zkau;jsessionid=030641C2F7D86A1D23CAD254708552D6", 
		"Action=http://bo.ezmall.vn/zkau;jsessionid={JSESSIONID5}", 
		"Method=POST", 
		"RecContentType=text/plain", 
		"Referer=http://bo.ezmall.vn/", 
		"Snapshot=t2.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=dtid", "Value=Desktop_29", ENDITEM, 
		"Name=cmd_0", "Value=onChange", ENDITEM, 
		"Name=uuid_0", "Value=Textbox_1", ENDITEM, 
		"Name=data_0", "Value={\"value\":\"demo\",\"start\":4}", ENDITEM, 
		"Name=cmd_1", "Value=onChange", ENDITEM, 
		"Name=uuid_1", "Value=Textbox_2", ENDITEM, 
		"Name=data_1", "Value={\"value\":\"mbh2012\",\"start\":7}", ENDITEM, 
		"Name=cmd_2", "Value=onChange", ENDITEM, 
		"Name=uuid_2", "Value=Textbox_3", ENDITEM, 
		"Name=data_2", "Value={\"value\":\"10002\",\"start\":5}", ENDITEM, 
		"Name=cmd_3", "Value=onClick", ENDITEM, 
		"Name=uuid_3", "Value=Button_18", ENDITEM, 
		"Name=data_3", "Value={\"pageX\":533,\"pageY\":454,\"which\":1,\"x\":74,\"y\":27}", ENDITEM, 
		EXTRARES, 
		"Url=/zkau/web/ec1a8cb9/sapphire/zul/img/wnd/wnd-ol-corner.png", "Referer=http://bo.ezmall.vn/zkau/web/ec1a8cb9/_zkiju-sapphire/zul/css/zk.wcs;jsessionid={JSESSIONID5}", ENDITEM, 
		"Url=/zkau/web/ec1a8cb9/sapphire/zul/img/wnd/wnd-ol-hm.png", "Referer=http://bo.ezmall.vn/zkau/web/ec1a8cb9/_zkiju-sapphire/zul/css/zk.wcs;jsessionid={JSESSIONID5}", ENDITEM, 
		"Url=/media/images/chon-cua-hang-1_05.gif", "Referer=http://bo.ezmall.vn/media/css/style_vi.css.dsp;jsessionid={JSESSIONID5}", ENDITEM, 
		"Url=/media/images/chon-cua-hang-1_08.gif", "Referer=http://bo.ezmall.vn/media/css/style_vi.css.dsp;jsessionid={JSESSIONID5}", ENDITEM, 
		"Url=/media/images/IconTest/triagle_btn_15x13.png", "Referer=http://bo.ezmall.vn/media/css/style_vi.css.dsp;jsessionid={JSESSIONID5}", ENDITEM, 
		LAST);

	lr_end_transaction("dang_nhap_tran",LR_AUTO);

	lr_think_time(3);

	return 0;
}
