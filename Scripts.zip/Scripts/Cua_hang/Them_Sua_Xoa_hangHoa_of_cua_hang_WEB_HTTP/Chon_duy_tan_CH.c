Chon_duy_tan_CH()
{

	lr_start_transaction("duy_tan_trans");

	web_add_cookie("PREF=ID=6669a4bc5f8cbeaf:U=700ad4a2d3d15391:FF=0:TM=1372252149:LM=1372654812:S=xP580yOB-wz-T-eF; DOMAIN=safebrowsing.clients.google.com");

	web_add_cookie("NID=67=BQh52riVuK5Is3zTV8yWjgMztvSx4193H3X2paH1LFILZVlMKPQaTnec4r6QX-IE4G-RlW9uTdDOHZIxccEilH02U6ycnrKLm5Uvn0U8rs9VcHxKEyCT-Upihdc_S6id; DOMAIN=safebrowsing.clients.google.com");

	web_add_cookie("PREF=ID=6669a4bc5f8cbeaf:U=700ad4a2d3d15391:FF=0:TM=1372252149:LM=1372654812:S=xP580yOB-wz-T-eF; DOMAIN=safebrowsing-cache.google.com");

	web_add_cookie("NID=67=BQh52riVuK5Is3zTV8yWjgMztvSx4193H3X2paH1LFILZVlMKPQaTnec4r6QX-IE4G-RlW9uTdDOHZIxccEilH02U6ycnrKLm5Uvn0U8rs9VcHxKEyCT-Upihdc_S6id; DOMAIN=safebrowsing-cache.google.com");

	lr_think_time(34);

	web_custom_request("downloads", 
		"URL=http://safebrowsing.clients.google.com/safebrowsing/downloads?client=navclient-auto-ffox&appver=22.0&pver=2.2&wrkey=AKEgNivl4yvaBoE3f0-e0F49dLRc927ds_EOrJANA8Tj9e3JYIGzl4AI0zk_IXRylBc9za-MD-ykVjRa8e8ltLgewABxZhExWA==", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/vnd.google.safebrowsing-update", 
		"Referer=", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		"EncType=text/plain", 
		"Body=goog-malware-shavar;a:111607-120465:s:110081-117436:mac\ngoog-phish-shavar;a:284273-292146:s:136714-140953:mac\n", 
		EXTRARES, 
		"Url=http://safebrowsing-cache.google.com/safebrowsing/rd/ChNnb29nLW1hbHdhcmUtc2hhdmFyEAEYuZUHIL6VBzIFucoBAD8", "Referer=", ENDITEM, 
		"Url=http://safebrowsing-cache.google.com/safebrowsing/rd/ChNnb29nLW1hbHdhcmUtc2hhdmFyEAEYv5UHIMSVBzIFv8oBAD8", "Referer=", ENDITEM, 
		"Url=http://safebrowsing-cache.google.com/safebrowsing/rd/ChNnb29nLW1hbHdhcmUtc2hhdmFyEAEYwZUHIICYByofKssBAP__________________________________fzISwcoBAP________________8B", "Referer=", ENDITEM, 
		"Url=http://safebrowsing-cache.google.com/safebrowsing/rd/"
		"ChNnb29nLW1hbHdhcmUtc2hhdmFyEAAYgawHIIDAByqeAjfXAQD______________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________wMyKwHWAQD__________________________________________________z8", "Referer=", ENDITEM, 
		"Url=http://safebrowsing-cache.google.com/safebrowsing/rd/ChFnb29nLXBoaXNoLXNoYXZhchABGJnNCCCezQgyBZkmAgA_", "Referer=", ENDITEM, 
		"Url=http://safebrowsing-cache.google.com/safebrowsing/rd/ChFnb29nLXBoaXNoLXNoYXZhchABGJ_NCCCkzQgyBZ8mAgA_", "Referer=", ENDITEM, 
		"Url=http://safebrowsing-cache.google.com/safebrowsing/rd/ChFnb29nLXBoaXNoLXNoYXZhchABGKHNCCDAzggqBjcnAgD_AzIXoSYCAP_______________________z8", "Referer=", ENDITEM, 
		"Url=http://safebrowsing-cache.google.com/safebrowsing/rd/ChFnb29nLXBoaXNoLXNoYXZhchAAGLPqESC46hEyBTN1BAA_", "Referer=", ENDITEM, 
		"Url=http://safebrowsing-cache.google.com/safebrowsing/rd/ChFnb29nLXBoaXNoLXNoYXZhchAAGLfqESDA6hEyBjd1BAD_Aw", "Referer=", ENDITEM, 
		"Url=http://safebrowsing-cache.google.com/safebrowsing/rd/ChFnb29nLXBoaXNoLXNoYXZhchAAGMHqESCA7REqECR2BAD______________x8yIUF1BAD_____________________________________Bw", "Referer=", ENDITEM, 
		LAST);

	web_submit_data("zkau;jsessionid=030641C2F7D86A1D23CAD254708552D6_2", 
		"Action=http://bo.ezmall.vn/zkau;jsessionid={JSESSIONID5}", 
		"Method=POST", 
		"RecContentType=text/plain", 
		"Referer=http://bo.ezmall.vn/", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=dtid", "Value=Desktop_29", ENDITEM, 
		"Name=cmd_0", "Value=onMove", ENDITEM, 
		"Name=opt_0", "Value=i", ENDITEM, 
		"Name=uuid_0", "Value=AA008ChooseLocationWindow_1", ENDITEM, 
		"Name=data_0", "Value={\"left\":\"309px\",\"top\":\"118px\"}", ENDITEM, 
		"Name=cmd_1", "Value=onZIndex", ENDITEM, 
		"Name=opt_1", "Value=i", ENDITEM, 
		"Name=uuid_1", "Value=AA008ChooseLocationWindow_1", ENDITEM, 
		"Name=data_1", "Value={\"\":1800}", ENDITEM, 
		"Name=cmd_2", "Value=onMove", ENDITEM, 
		"Name=opt_2", "Value=i", ENDITEM, 
		"Name=uuid_2", "Value=AA008ChooseLocationWindow_1", ENDITEM, 
		"Name=data_2", "Value={\"left\":\"309px\",\"top\":\"117px\"}", ENDITEM, 
		"Name=cmd_3", "Value=onClick", ENDITEM, 
		"Name=uuid_3", "Value=Button_20", ENDITEM, 
		"Name=data_3", "Value={\"pageX\":438,\"pageY\":255,\"which\":1,\"x\":37,\"y\":45.5}", ENDITEM, 
		EXTRARES, 
		"Url=/zkau/web/_zv2013032614/js/zhtml.wpd;jsessionid={JSESSIONID5}", "Referer=http://bo.ezmall.vn/", ENDITEM, 
		"Url=/zkau/web/_zv2013032614/js/zul.fchart2.wpd;jsessionid={JSESSIONID5}", "Referer=http://bo.ezmall.vn/", ENDITEM, 
		"Url=/zkau/web/_zv2013032614/js/zkex.grid.wpd;jsessionid={JSESSIONID5}", "Referer=http://bo.ezmall.vn/", ENDITEM, 
		"Url=/zkau/web/_zv2013032614/js/zul.grid.wpd;jsessionid={JSESSIONID5}", "Referer=http://bo.ezmall.vn/", ENDITEM, 
		"Url=/zkau/web/_zv2013032614/js/zul.tab.wpd;jsessionid={JSESSIONID5}", "Referer=http://bo.ezmall.vn/", ENDITEM, 
		"Url=/zkau/web/_zv2013032614/js/zul.db.wpd;jsessionid={JSESSIONID5}", "Referer=http://bo.ezmall.vn/", ENDITEM, 
		"Url=/zkau/web/_zv2013032614/js/zul.med.wpd;jsessionid={JSESSIONID5}", "Referer=http://bo.ezmall.vn/", ENDITEM, 
		"Url=/zkau/web/ec1a8cb9/ezpaging/images/pagination_first_dis.png", "Referer=http://bo.ezmall.vn/", ENDITEM, 
		"Url=/media/images/faq_256.gif", "Referer=http://bo.ezmall.vn/", ENDITEM, 
		"Url=/zkau/web/ec1a8cb9/ezpaging/images/pagination_prev_dis.png", "Referer=http://bo.ezmall.vn/", ENDITEM, 
		"Url=/zkau/web/ec1a8cb9/ezpaging/images/load.png", "Referer=http://bo.ezmall.vn/", ENDITEM, 
		"Url=/zkau/web/ec1a8cb9/ezpaging/images/pagination_next_dis.png", "Referer=http://bo.ezmall.vn/", ENDITEM, 
		"Url=/zkau/web/ec1a8cb9/ezpaging/images/pagination_last_dis.png", "Referer=http://bo.ezmall.vn/", ENDITEM, 
		"Url=/media/images/winpos.gif", "Referer=http://bo.ezmall.vn/", ENDITEM, 
		"Url=/media/images/help_icon.png", "Referer=http://bo.ezmall.vn/", ENDITEM, 
		"Url=/media/images/www.gif", "Referer=http://bo.ezmall.vn/", ENDITEM, 
		"Url=/media/images/tab_android.gif", "Referer=http://bo.ezmall.vn/", ENDITEM, 
		"Url=/media/images/iphone.gif", "Referer=http://bo.ezmall.vn/", ENDITEM, 
		"Url=/media/images/ipad.png", "Referer=http://bo.ezmall.vn/", ENDITEM, 
		"Url=/media/images/sodo_hethong_01.gif", "Referer=http://bo.ezmall.vn/", ENDITEM, 
		"Url=/media/images/spacer.gif", "Referer=http://bo.ezmall.vn/", ENDITEM, 
		"Url=/media/images/sodo_hethong_02.gif", "Referer=http://bo.ezmall.vn/", ENDITEM, 
		"Url=/media/images/sodo_hethong_03.png", "Referer=http://bo.ezmall.vn/", ENDITEM, 
		"Url=/media/images/sodo_hethong_05.png", "Referer=http://bo.ezmall.vn/", ENDITEM, 
		"Url=/media/images/sodo_hethong_08.png", "Referer=http://bo.ezmall.vn/", ENDITEM, 
		"Url=/media/images/sodo_hethong_10.png", "Referer=http://bo.ezmall.vn/", ENDITEM, 
		"Url=/media/images/sodo_hethong_11.gif", "Referer=http://bo.ezmall.vn/", ENDITEM, 
		"Url=/media/images/sodo_hethong_13.gif", "Referer=http://bo.ezmall.vn/", ENDITEM, 
		"Url=/media/images/sodo_hethong_15.gif", "Referer=http://bo.ezmall.vn/", ENDITEM, 
		"Url=/media/images/sodo_hethong_17.gif", "Referer=http://bo.ezmall.vn/", ENDITEM, 
		"Url=/media/images/sodo_hethong_21.gif", "Referer=http://bo.ezmall.vn/", ENDITEM, 
		"Url=/media/images/sodo_hethong_18.gif", "Referer=http://bo.ezmall.vn/", ENDITEM, 
		"Url=/media/images/bg_content.gif", "Referer=http://bo.ezmall.vn/media/css/style_vi.css.dsp;jsessionid={JSESSIONID5}", ENDITEM, 
		"Url=/media/images/blk_bg.gif", "Referer=http://bo.ezmall.vn/media/css/style_vi.css.dsp;jsessionid={JSESSIONID5}", ENDITEM, 
		"Url=/media/images/yahoo.png", "Referer=http://bo.ezmall.vn/media/css/style_vi.css.dsp;jsessionid={JSESSIONID5}", ENDITEM, 
		"Url=/media/images/support.png", "Referer=http://bo.ezmall.vn/media/css/style_vi.css.dsp;jsessionid={JSESSIONID5}", ENDITEM, 
		"Url=/media/images/sky.png", "Referer=http://bo.ezmall.vn/media/css/style_vi.css.dsp;jsessionid={JSESSIONID5}", ENDITEM, 
		"Url=/media/images/phone.png", "Referer=http://bo.ezmall.vn/media/css/style_vi.css.dsp;jsessionid={JSESSIONID5}", ENDITEM, 
		"Url=/media/images/mail.png", "Referer=http://bo.ezmall.vn/media/css/style_vi.css.dsp;jsessionid={JSESSIONID5}", ENDITEM, 
		"Url=/zkau/web/ec1a8cb9/sapphire/zul/img/tab/tab-corner.png", "Referer=http://bo.ezmall.vn/zkau/web/ec1a8cb9/_zkiju-sapphire/zul/css/zk.wcs;jsessionid={JSESSIONID5}", ENDITEM, 
		"Url=/zkau/web/ec1a8cb9/sapphire/zul/img/tab/tab-hm.png", "Referer=http://bo.ezmall.vn/zkau/web/ec1a8cb9/_zkiju-sapphire/zul/css/zk.wcs;jsessionid={JSESSIONID5}", ENDITEM, 
		"Url=/zkau/web/ec1a8cb9/sapphire/zul/img/input/datebtn.gif", "Referer=http://bo.ezmall.vn/zkau/web/ec1a8cb9/_zkiju-sapphire/zul/css/zk.wcs;jsessionid={JSESSIONID5}", ENDITEM, 
		"Url=/zkau/web/ec1a8cb9/sapphire/zul/img/grid/column-bg.png", "Referer=http://bo.ezmall.vn/zkau/web/ec1a8cb9/_zkiju-sapphire/zul/css/zk.wcs;jsessionid={JSESSIONID5}", ENDITEM, 
		"Url=/zkau/web/ec1a8cb9/zul/img/grid/row-expand.png", "Referer=http://bo.ezmall.vn/zkau/web/ec1a8cb9/_zkiju-sapphire/zul/css/zk.wcs;jsessionid={JSESSIONID5}", ENDITEM, 
		"Url=/media/images/Centigrade-Widget-Icons/Bullet-10x10.png", "Referer=http://bo.ezmall.vn/media/css/ezstore.css.dsp;jsessionid={JSESSIONID5}", ENDITEM, 
		"Url=/media/images/breeze-category-bg.png", "Referer=http://bo.ezmall.vn/media/css/ezstore.css.dsp;jsessionid={JSESSIONID5}", ENDITEM, 
		LAST);

	lr_end_transaction("duy_tan_trans",LR_AUTO);

	lr_think_time(3);

	return 0;
}
