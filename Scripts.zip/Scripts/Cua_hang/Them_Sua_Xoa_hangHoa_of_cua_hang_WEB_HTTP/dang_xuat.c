dang_xuat()
{

	lr_start_transaction("dang_xuat");

	lr_think_time(23);

	web_submit_data("zkau;jsessionid=030641C2F7D86A1D23CAD254708552D6_39", 
		"Action=http://bo.ezmall.vn/zkau;jsessionid={JSESSIONID5}", 
		"Method=POST", 
		"RecContentType=text/plain", 
		"Referer=http://bo.ezmall.vn/", 
		"Snapshot=t41.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=dtid", "Value=Desktop_29", ENDITEM, 
		"Name=cmd_0", "Value=onClick", ENDITEM, 
		"Name=uuid_0", "Value=Button_2", ENDITEM, 
		"Name=data_0", "Value={\"pageX\":1071,\"pageY\":25,\"which\":1,\"x\":28,\"y\":12}", ENDITEM, 
		LAST);

	web_url("bo.ezmall.vn_2", 
		"URL=http://bo.ezmall.vn/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://bo.ezmall.vn/", 
		"Snapshot=t42.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/zkau/web/_zv2013032614/js/zul.layout.wpd", ENDITEM, 
		"Url=/zkau/web/_zv2013032614/js/zul.box.wpd", ENDITEM, 
		"Url=/zkau/web/_zv2013032614/js/zul.wnd.wpd", ENDITEM, 
		"Url=/zkau/web/_zv2013032614/js/zul.inp.wpd", ENDITEM, 
		"Url=/zkau/web/_zv2013032614/js/zul.sel.wpd", ENDITEM, 
		"Url=/zkau/web/_zv2013032614/js/zk.fmt.wpd", ENDITEM, 
		"Url=/zkau/web/_zv2013032614/js/zul.mesh.wpd", ENDITEM, 
		"Url=/zkau/web/_zv2013032614/js/zul.menu.wpd", ENDITEM, 
		"Url=/media/images/icon_header/location_icon_16x21.png", ENDITEM, 
		"Url=/media/images/IconTest/maybanhang_logo_251x44.png", ENDITEM, 
		"Url=/media/images/icon_header/support_icon_25x25.png", ENDITEM, 
		"Url=/media/images/icon_header/cuahang52x52.png", ENDITEM, 
		"Url=/media/images/icon_header/dashboard52x52.png", ENDITEM, 
		"Url=/media/images/vi.png", ENDITEM, 
		"Url=/media/images/icon_header/khachhang52x52.png", ENDITEM, 
		"Url=/media/images/icon_header/khohang52x52.png", ENDITEM, 
		"Url=/media/images/icon_header/order52x52.png", ENDITEM, 
		"Url=/media/images/icon_header/invoice52x52.png", ENDITEM, 
		"Url=/media/images/icon_header/cash52x52.png", ENDITEM, 
		"Url=/media/images/icon_header/baocao52x52.png", ENDITEM, 
		"Url=/media/images/icon_header/email52x52.png", ENDITEM, 
		"Url=/media/images/icon_header/setting52x52.png", ENDITEM, 
		"Url=/media/images/icon_header/taikhoan52x52.png", ENDITEM, 
		"Url=/media/images/icon_header/nhanvien52x52.png", ENDITEM, 
		"Url=/media/images/icon_header/support52x52.png", ENDITEM, 
		LAST);

	lr_end_transaction("dang_xuat",LR_AUTO);

	lr_think_time(3);

	return 0;
}