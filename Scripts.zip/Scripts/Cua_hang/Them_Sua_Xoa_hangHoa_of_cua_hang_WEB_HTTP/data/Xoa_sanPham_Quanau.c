Xoa_sanPham_Quanau()
{

	lr_start_transaction("Xoa_sanPham_Quanau_trans");

	lr_think_time(42);

	web_submit_data("zkau;jsessionid=030641C2F7D86A1D23CAD254708552D6_33", 
		"Action=http://bo.ezmall.vn/zkau;jsessionid={JSESSIONID5}", 
		"Method=POST", 
		"RecContentType=text/plain", 
		"Referer=http://bo.ezmall.vn/", 
		"Snapshot=t35.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=dtid", "Value=Desktop_29", ENDITEM, 
		"Name=cmd_0", "Value=onClick", ENDITEM, 
		"Name=uuid_0", "Value=Div_49", ENDITEM, 
		"Name=data_0", "Value={\"pageX\":992,\"pageY\":179,\"which\":1,\"x\":16.79998779296875,\"y\":10}", ENDITEM, 
		EXTRARES, 
		"Url=/zkau/web/ec1a8cb9/ezpaging/images/pagination_first.png", "Referer=http://bo.ezmall.vn/", ENDITEM, 
		"Url=/zkau/web/ec1a8cb9/ezpaging/images/pagination_prev.png", "Referer=http://bo.ezmall.vn/", ENDITEM, 
		LAST);

	web_submit_data("zkau;jsessionid=030641C2F7D86A1D23CAD254708552D6_34", 
		"Action=http://bo.ezmall.vn/zkau;jsessionid={JSESSIONID5}", 
		"Method=POST", 
		"RecContentType=text/plain", 
		"Referer=http://bo.ezmall.vn/", 
		"Snapshot=t36.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=dtid", "Value=Desktop_29", ENDITEM, 
		"Name=cmd_0", "Value=onClick", ENDITEM, 
		"Name=uuid_0", "Value=Div_49", ENDITEM, 
		"Name=data_0", "Value={\"pageX\":984,\"pageY\":181,\"which\":1,\"x\":14.79998779296875,\"y\":12}", ENDITEM, 
		LAST);

	web_submit_data("zkau;jsessionid=030641C2F7D86A1D23CAD254708552D6_35", 
		"Action=http://bo.ezmall.vn/zkau;jsessionid={JSESSIONID5}", 
		"Method=POST", 
		"RecContentType=text/plain", 
		"Referer=http://bo.ezmall.vn/", 
		"Snapshot=t37.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=dtid", "Value=Desktop_29", ENDITEM, 
		"Name=cmd_0", "Value=onClick", ENDITEM, 
		"Name=uuid_0", "Value=Div_49", ENDITEM, 
		"Name=data_0", "Value={\"pageX\":980,\"pageY\":178,\"which\":1,\"x\":11.79998779296875,\"y\":9}", ENDITEM, 
		EXTRARES, 
		"Url=/media/images/IconTest/delete_icon22x22.png", "Referer=http://bo.ezmall.vn/", ENDITEM, 
		LAST);

	web_submit_data("zkau;jsessionid=030641C2F7D86A1D23CAD254708552D6_36", 
		"Action=http://bo.ezmall.vn/zkau;jsessionid={JSESSIONID5}", 
		"Method=POST", 
		"RecContentType=text/plain", 
		"Referer=http://bo.ezmall.vn/", 
		"Snapshot=t38.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=dtid", "Value=Desktop_29", ENDITEM, 
		"Name=cmd_0", "Value=onClick", ENDITEM, 
		"Name=uuid_0", "Value=Div_49", ENDITEM, 
		"Name=data_0", "Value={\"pageX\":980,\"pageY\":178,\"which\":1,\"x\":11.79998779296875,\"y\":9}", ENDITEM, 
		LAST);

	lr_think_time(4);

	web_submit_data("zkau;jsessionid=030641C2F7D86A1D23CAD254708552D6_37", 
		"Action=http://bo.ezmall.vn/zkau;jsessionid={JSESSIONID5}", 
		"Method=POST", 
		"RecContentType=text/plain", 
		"Referer=http://bo.ezmall.vn/", 
		"Snapshot=t39.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=dtid", "Value=Desktop_29", ENDITEM, 
		"Name=cmd_0", "Value=onClick", ENDITEM, 
		"Name=uuid_0", "Value=Comboitem_33", ENDITEM, 
		"Name=data_0", "Value={\"pageX\":402,\"pageY\":352,\"which\":1,\"x\":14,\"y\":12}", ENDITEM, 
		EXTRARES, 
		"Url=/zkau/web/ec1a8cb9/sapphire/zul/img/msgbox/question-btn.png", "Referer=http://bo.ezmall.vn/zkau/web/ec1a8cb9/_zkiju-sapphire/zul/css/zk.wcs;jsessionid={JSESSIONID5}", ENDITEM, 
		LAST);

	web_submit_data("zkau;jsessionid=030641C2F7D86A1D23CAD254708552D6_38", 
		"Action=http://bo.ezmall.vn/zkau;jsessionid={JSESSIONID5}", 
		"Method=POST", 
		"RecContentType=text/plain", 
		"Referer=http://bo.ezmall.vn/", 
		"Snapshot=t40.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=dtid", "Value=Desktop_29", ENDITEM, 
		"Name=cmd_0", "Value=onMove", ENDITEM, 
		"Name=opt_0", "Value=i", ENDITEM, 
		"Name=uuid_0", "Value=Comboitem_45", ENDITEM, 
		"Name=data_0", "Value={\"left\":\"435px\",\"top\":\"100px\"}", ENDITEM, 
		"Name=cmd_1", "Value=onZIndex", ENDITEM, 
		"Name=opt_1", "Value=i", ENDITEM, 
		"Name=uuid_1", "Value=Comboitem_45", ENDITEM, 
		"Name=data_1", "Value={\"\":1800}", ENDITEM, 
		"Name=cmd_2", "Value=onClick", ENDITEM, 
		"Name=uuid_2", "Value=Label_150", ENDITEM, 
		"Name=data_2", "Value={\"pageX\":588,\"pageY\":216,\"which\":1,\"x\":56.29998779296875,\"y\":19}", ENDITEM, 
		LAST);

	lr_end_transaction("Xoa_sanPham_Quanau_trans",LR_AUTO);

	lr_think_time(3);

	return 0;
}
