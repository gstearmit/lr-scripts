Sua_sanPham_CafeTrung_nguyen()
{

	lr_start_transaction("Sua_sanPham_CafeTrung_nguyen");

	lr_think_time(54);

	web_submit_data("zkau;jsessionid=030641C2F7D86A1D23CAD254708552D6_26", 
		"Action=http://bo.ezmall.vn/zkau;jsessionid={JSESSIONID5}", 
		"Method=POST", 
		"RecContentType=text/plain", 
		"Referer=http://bo.ezmall.vn/", 
		"Snapshot=t28.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=dtid", "Value=Desktop_29", ENDITEM, 
		"Name=cmd_0", "Value=onClick", ENDITEM, 
		"Name=uuid_0", "Value=Label_602", ENDITEM, 
		"Name=data_0", "Value={\"pageX\":371,\"pageY\":352,\"which\":1,\"x\":13,\"y\":12}", ENDITEM, 
		EXTRARES, 
		"Url=/zkau/view/Desktop_29/Label_541/fg41/1/c/a.png", "Referer=http://bo.ezmall.vn/", ENDITEM, 
		LAST);

	lr_think_time(12);

	web_custom_request("zkau;jsessionid=030641C2F7D86A1D23CAD254708552D6_27", 
		"URL=http://bo.ezmall.vn/zkau;jsessionid={JSESSIONID5}", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=http://bo.ezmall.vn/", 
		"Snapshot=t29.inf", 
		"Mode=HTML", 
		"EncType=application/x-www-form-urlencoded;charset=UTF-8", 
		"Body=dtid=Desktop_29&cmd_0=onMove&opt_0=i&uuid_0=Label_561&data_0=%7B%22left%22%3A%22284px%22%2C%22top%22%3A%222px%22%7D&cmd_1=onZIndex&opt_1=i&uuid_1=Label_561&data_1=%7B%22%22%3A1800%7D&cmd_2=onChange&uuid_2=Label_928&data_2=%7B%22value%22%3A%22Cafe%20Trung%20Nguy%C3%AAn%20G9%22%2C%22start%22%3A20%7D&cmd_3=onChange&uuid_3=Tabbox_1&data_3=%7B%22value%22%3A%2245.000%22%2C%22start%22%3A1%7D&cmd_4=onBlur&uuid_4=Tabbox_1", 
		LAST);

	web_submit_data("zkau;jsessionid=030641C2F7D86A1D23CAD254708552D6_28", 
		"Action=http://bo.ezmall.vn/zkau;jsessionid={JSESSIONID5}", 
		"Method=POST", 
		"RecContentType=text/plain", 
		"Referer=http://bo.ezmall.vn/", 
		"Snapshot=t30.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=dtid", "Value=Desktop_29", ENDITEM, 
		"Name=cmd_0", "Value=onBlur", ENDITEM, 
		"Name=uuid_0", "Value=Tabbox_1", ENDITEM, 
		LAST);

	lr_think_time(5);

	web_submit_data("zkau;jsessionid=030641C2F7D86A1D23CAD254708552D6_29", 
		"Action=http://bo.ezmall.vn/zkau;jsessionid={JSESSIONID5}", 
		"Method=POST", 
		"RecContentType=text/plain", 
		"Referer=http://bo.ezmall.vn/", 
		"Snapshot=t31.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=dtid", "Value=Desktop_29", ENDITEM, 
		"Name=cmd_0", "Value=onChange", ENDITEM, 
		"Name=uuid_0", "Value=Html_6", ENDITEM, 
		"Name=data_0", "Value={\"value\":\"3.000\",\"start\":1}", ENDITEM, 
		"Name=cmd_1", "Value=onBlur", ENDITEM, 
		"Name=uuid_1", "Value=Html_6", ENDITEM, 
		LAST);

	web_submit_data("zkau;jsessionid=030641C2F7D86A1D23CAD254708552D6_30", 
		"Action=http://bo.ezmall.vn/zkau;jsessionid={JSESSIONID5}", 
		"Method=POST", 
		"RecContentType=text/plain", 
		"Referer=http://bo.ezmall.vn/", 
		"Snapshot=t32.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=dtid", "Value=Desktop_29", ENDITEM, 
		"Name=cmd_0", "Value=onChange", ENDITEM, 
		"Name=uuid_0", "Value=Html_6", ENDITEM, 
		"Name=data_0", "Value={\"value\":\"35.000\",\"start\":2}", ENDITEM, 
		"Name=cmd_1", "Value=onBlur", ENDITEM, 
		"Name=uuid_1", "Value=Html_6", ENDITEM, 
		LAST);

	web_submit_data("zkau;jsessionid=030641C2F7D86A1D23CAD254708552D6_31", 
		"Action=http://bo.ezmall.vn/zkau;jsessionid={JSESSIONID5}", 
		"Method=POST", 
		"RecContentType=text/plain", 
		"Referer=http://bo.ezmall.vn/", 
		"Snapshot=t33.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=dtid", "Value=Desktop_29", ENDITEM, 
		"Name=cmd_0", "Value=onBlur", ENDITEM, 
		"Name=uuid_0", "Value=Html_6", ENDITEM, 
		LAST);

	web_submit_data("zkau;jsessionid=030641C2F7D86A1D23CAD254708552D6_32", 
		"Action=http://bo.ezmall.vn/zkau;jsessionid={JSESSIONID5}", 
		"Method=POST", 
		"RecContentType=text/plain", 
		"Referer=http://bo.ezmall.vn/", 
		"Snapshot=t34.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=dtid", "Value=Desktop_29", ENDITEM, 
		"Name=cmd_0", "Value=onClick", ENDITEM, 
		"Name=uuid_0", "Value=Label_694", ENDITEM, 
		"Name=data_0", "Value={\"pageX\":574,\"pageY\":511,\"which\":1,\"x\":58.5,\"y\":13}", ENDITEM, 
		LAST);

	lr_end_transaction("Sua_sanPham_CafeTrung_nguyen",LR_AUTO);

	lr_think_time(3);

	return 0;
}
