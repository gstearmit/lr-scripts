Action()
{

	
	web_set_max_html_param_len("1024");

	/* Registering parameter(s) from source task id 10
	// {JSESSIONID5} = "030641C2F7D86A1D23CAD254708552D6"
	// */

	web_reg_save_param("JSESSIONID5", 
		"LB/IC=jsessionid=", 
		"RB/IC=\"", 
		"Ord=1", 
		"Search=body", 
		"RelFrameId=1", 
		LAST);

	web_url("bo.ezmall.vn", 
		"URL=http://bo.ezmall.vn/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/zkau/web/ec1a8cb9/sapphire/zul/img/misc/progress.gif", "Referer=http://bo.ezmall.vn/zkau/web/ec1a8cb9/_zkiju-sapphire/zul/css/zk.wcs;jsessionid={JSESSIONID5}", ENDITEM, 
		"Url=/media/images/maybanhang.png", "Referer=http://bo.ezmall.vn/media/css/ezstore.css.dsp;jsessionid={JSESSIONID5}", ENDITEM, 
		"Url=/zkau/web/_zv2013032614/js/zul.layout.wpd;jsessionid={JSESSIONID5}", ENDITEM, 
		"Url=/zkau/web/_zv2013032614/js/zul.box.wpd;jsessionid={JSESSIONID5}", ENDITEM, 
		"Url=/zkau/web/_zv2013032614/js/zul.inp.wpd;jsessionid={JSESSIONID5}", ENDITEM, 
		"Url=/zkau/web/_zv2013032614/js/zul.wnd.wpd;jsessionid={JSESSIONID5}", ENDITEM, 
		"Url=/zkau/web/_zv2013032614/js/zul.sel.wpd;jsessionid={JSESSIONID5}", ENDITEM, 
		"Url=/zkau/web/_zv2013032614/js/zul.mesh.wpd;jsessionid={JSESSIONID5}", ENDITEM, 
		"Url=/zkau/web/_zv2013032614/js/zk.fmt.wpd;jsessionid={JSESSIONID5}", ENDITEM, 
		"Url=/zkau/web/_zv2013032614/js/zul.menu.wpd;jsessionid={JSESSIONID5}", ENDITEM, 
		"Url=/media/images/IconTest/maybanhang_logo_251x44.png;jsessionid={JSESSIONID5}", ENDITEM, 
		"Url=/media/images/icon_header/location_icon_16x21.png;jsessionid={JSESSIONID5}", ENDITEM, 
		"Url=/media/images/icon_header/support_icon_25x25.png;jsessionid={JSESSIONID5}", ENDITEM, 
		"Url=/media/images/icon_header/dashboard52x52.png;jsessionid={JSESSIONID5}", ENDITEM, 
		"Url=/media/images/icon_header/cuahang52x52.png;jsessionid={JSESSIONID5}", ENDITEM, 
		"Url=/media/images/vi.png;jsessionid={JSESSIONID5}", ENDITEM, 
		"Url=/media/images/icon_header/khachhang52x52.png;jsessionid={JSESSIONID5}", ENDITEM, 
		"Url=/media/images/icon_header/khohang52x52.png;jsessionid={JSESSIONID5}", ENDITEM, 
		"Url=/media/images/icon_header/cash52x52.png;jsessionid={JSESSIONID5}", ENDITEM, 
		"Url=/media/images/icon_header/order52x52.png;jsessionid={JSESSIONID5}", ENDITEM, 
		"Url=/media/images/icon_header/baocao52x52.png;jsessionid={JSESSIONID5}", ENDITEM, 
		"Url=/media/images/icon_header/invoice52x52.png;jsessionid={JSESSIONID5}", ENDITEM, 
		"Url=/media/images/icon_header/email52x52.png;jsessionid={JSESSIONID5}", ENDITEM, 
		"Url=/media/images/icon_header/setting52x52.png;jsessionid={JSESSIONID5}", ENDITEM, 
		"Url=/media/images/icon_header/taikhoan52x52.png;jsessionid={JSESSIONID5}", ENDITEM, 
		"Url=/media/images/icon_header/nhanvien52x52.png;jsessionid={JSESSIONID5}", ENDITEM, 
		"Url=/media/images/icon_header/support52x52.png;jsessionid={JSESSIONID5}", ENDITEM, 
		"Url=/zkau/web/ec1a8cb9/sapphire/zul/img/splt/colps-t.png", "Referer=http://bo.ezmall.vn/zkau/web/ec1a8cb9/_zkiju-sapphire/zul/css/zk.wcs;jsessionid={JSESSIONID5}", ENDITEM, 
		"Url=/zkau/web/ec1a8cb9/sapphire/zul/img/splt/splt-v.png", "Referer=http://bo.ezmall.vn/zkau/web/ec1a8cb9/_zkiju-sapphire/zul/css/zk.wcs;jsessionid={JSESSIONID5}", ENDITEM, 
		"Url=/zkau/web/ec1a8cb9/sapphire/zul/img/splt/splt-h.png", "Referer=http://bo.ezmall.vn/zkau/web/ec1a8cb9/_zkiju-sapphire/zul/css/zk.wcs;jsessionid={JSESSIONID5}", ENDITEM, 
		LAST);

	return 0;
}
