   !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
   !!                                                                               !!
   !!                    	  PLEASE NOTE											!!
   !!                   	  ===========											!!
   !!                                                                               !!
   !!    This view is a READ-ONLY representation of the script.                     !!
   !!                                                                               !!
   !!    Use the Firefox TruClient sidebar to develop, edit and enhance the script. !!
   !!                                                                               !!
   !!    Select the DEVELOP SCRIPT button to open the Firefox TruClient sidebar.    !!
   !!                                                                               !!
   !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!


F(){
/*
	1	Action:Navigate to "http://bo.ezmall.vn/"
	4	Action:Type "demo" in Tên đăng nhập textbox
	5	Action:Type ●●●●●●●●● in Mật khẩu passwordbox
	8	Action:Type "10002" in Mã cửa hàng textbox
	10	Action:Click on Đăng nhập gridcell
	12	Action:Click on button button
	13	Action:Mouse Over
	13.3	Action:Move mouse over CỬA HÀNG
	14	Action:Click on CỬA HÀNG
	16	Action:Click on Thêm mới gridcell
	18	Action:Type "23456tyy76" in Mã vạch textbox
	22	Action:Type "quan" in Tên sản phẩm textbox
	25	Action:Type "Quần Bò" in Tên sản phẩm textbox
	28	Action:Type "1" in Giá bán textbox
	29	Action:Type "7" in Giá bán textbox
	30	Action:Type "0" in Giá bán textbox
	31	Action:Type "0" in Giá bán textbox
	32	Action:Type "0" in Giá bán textbox
	33	Action:Type "0" in Giá bán textbox
	35	Action:Click on element (109)
	39	Action:Select "---Quần bò" from Áo Phông listbox
	42	Action:Type "1" in Giá nhập textbox
	43	Action:Type "1" in Giá nhập textbox
	44	Action:Type "0" in Giá nhập textbox
	45	Action:Type "0" in Giá nhập textbox
	46	Action:Type "0" in Giá nhập textbox
	47	Action:Type "0" in Giá nhập textbox
	49	Action:Click on Lưu gridcell
	50	Action:Click on Lưu gridcell
	53	Action:Type "5" in 1 textbox
	54	Action:Click on image (2) image
	56	Action:Click on Thêm mới gridcell
	58	Action:Type "1111wwww3455" in Mã vạch textbox
	60	Action:Type "Quần Ngố" in Tên sản phẩm textbox
	63	Action:Type "4" in Giá bán textbox
	64	Action:Type "5" in Giá bán textbox
	65	Action:Type "0" in Giá bán textbox
	66	Action:Type "0" in Giá bán textbox
	67	Action:Type "0" in Giá bán textbox
	68	Action:Type "0" in Giá bán textbox
	70	Action:Click on element (252)
	75	Action:Select "---Quần Ngố" from Áo Phông listbox
	78	Action:Type "2" in Giá nhập textbox
	79	Action:Type "3" in Giá nhập textbox
	80	Action:Type "0" in Giá nhập textbox
	81	Action:Type "0" in Giá nhập textbox
	82	Action:Type "2.300" in Giá nhập textbox
	83	Action:Type "0" in Giá nhập textbox
	84	Action:Type "0" in Giá nhập textbox
	86	Action:Click on Lưu gridcell
	87	Action:Click on Lưu gridcell
	90	Action:Type "5" in 1 textbox
	92	Action:Click on image (2) image
	94	Action:Click on button (2) button
	97	Action:Click on 450.000 textbox
	98	Action:Type "" in 450.000 textbox
	99	Action:Type "" in 450.000 textbox
	100	Action:Type "50.000" in 450.000 textbox
	101	Action:Type "2" in 450.000 textbox
	103	Action:Click on Lưu gridcell
	106	Action:Type "5" in 1 textbox
	108	Action:Click on image (2) image
	109	Action:Mouse Over
	109.2	Action:Move mouse over Quần Bò
	110	Action:Click on button (4) button
	111	Action:Mouse Over
	111.1	Action:Move mouse over z modal mask
	112	Action:Click on Chấp nhận gridcell
	116	Action:Type "5" in 1 textbox
	117	Action:Mouse Over
	117.2	Action:Move mouse over element (393)
	118	Action:Click on image (2) image
	120	Action:Click on Đăng xuất gridcell
*/
};
