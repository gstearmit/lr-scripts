   !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
   !!                                                                               !!
   !!                    	  PLEASE NOTE											!!
   !!                   	  ===========											!!
   !!                                                                               !!
   !!    This view is a READ-ONLY representation of the script.                     !!
   !!                                                                               !!
   !!    Use the Firefox TruClient sidebar to develop, edit and enhance the script. !!
   !!                                                                               !!
   !!    Select the DEVELOP SCRIPT button to open the Firefox TruClient sidebar.    !!
   !!                                                                               !!
   !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!


F(){
/*
	1	Action:Navigate to "http://bo.ezmall.vn/"
	5	Action:Type "demo" in Tên đăng nhập textbox
	6	Action:Type ●●●●●●●●● in Mật khẩu passwordbox
	7	Action:Type "10002" in Mã cửa hàng textbox
	9	Action:Click on Đăng nhập gridcell
	11	Action:Click on button (2) button
	12	Action:For ( var i = 0 ; i &lt; 2 ; i++ )
	12.1	Action:Wait 6 seconds
	12.2	Action:Evaluate JS ma_khach_hang = LR.getParam("ma_khach_hang")
	12.3	Action:Mouse Over
	12.3.5	Action:Move mouse over KHÁCH HÀNG image
	12.4	Action:Click on KHÁCH HÀNG
	12.6	Action:Click on Thêm mới gridcell
	12.8	Action:Wait 3 seconds
	12.11	Action:Type ma_khach_hang in Mã khách hàng textbox
	12.13	Action:Type "Thuo" in Tên khách hàng textbox
	12.18	Action:Type "Thương mại điện Tử" in Tên khách hàng textbox
	12.20	Action:Click on element (119)
	12.21	Action:Mouse Over
	12.21.5	Action:Move mouse over Nhóm cung cấp gridcell
	12.22	Action:Select "Nhóm cung cấp" from Bionline listbox
	12.25	Action:Type "0945678987" in ĐT di động textbox
	12.27	Action:Type "ezmailez@gmail.com" in Email textbox
	12.28	Action:Type "27/02/1987" in Ngày sinh textbox
	12.30	Action:Type "Hà Nội" in textbox (10) textbox
	12.33	Action:Type "Thương Mại điện Tử" in textbox (11) textbox
	12.35	Action:Type "0487888990" in Điện thoại textbox
	12.36	Action:Click on Lưu gridcell
	12.37	Action:Wait 3 seconds
	12.38	Action:Click on Lưu gridcell
	12.39	Action:Verify Mã khách hàng 's Visible Text contains ma_khach_hang+""
	13	Action:Mouse Over
	13.22	Action:Move mouse over element (194)
	14	Action:Click on Đăng xuất gridcell
*/
};
