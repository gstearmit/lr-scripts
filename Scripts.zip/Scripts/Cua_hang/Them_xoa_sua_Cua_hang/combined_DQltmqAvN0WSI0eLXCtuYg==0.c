#include "lrun.h"
#include "E:\Scripts HP LoadRunner\07_08_2012\bo.ezmall.vn\Scripts\Cua_hang\Them_xoa_sua_Cua_hang\C-functions.c"
