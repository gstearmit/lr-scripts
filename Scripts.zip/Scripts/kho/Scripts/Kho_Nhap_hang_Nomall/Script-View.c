   !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
   !!                                                                               !!
   !!                    	  PLEASE NOTE											!!
   !!                   	  ===========											!!
   !!                                                                               !!
   !!    This view is a READ-ONLY representation of the script.                     !!
   !!                                                                               !!
   !!    Use the Firefox TruClient sidebar to develop, edit and enhance the script. !!
   !!                                                                               !!
   !!    Select the DEVELOP SCRIPT button to open the Firefox TruClient sidebar.    !!
   !!                                                                               !!
   !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!


F(){
/*
	1	Action:Navigate to "http://bo.ezmall.vn/"
	5	Action:Type "demo" in Tên đăng nhập textbox
	6	Action:Type ●●●●●●●●● in Mật khẩu passwordbox
	7	Action:Type "10002" in Mã cửa hàng textbox
	9	Action:Click on Đăng nhập gridcell
	11	Action:Click on button button
	13	Action:Click on KHO
	14	Action:Click on Nhập hàng
	16	Action:Click on Thêm mới gridcell
	18	Action:Type "Áo Dài Nam" in Hủy hàng textbox
	20	Action:Click on Thêm SP gridcell
	27	Action:Type "323s4232322" in Mã vạch textbox
	30	Action:Type "Áo Chim Cò Nam" in Tên sản phẩm textbox
	31	Action:Mouse Over
	31.1	Action:Move mouse over Áo Phông textbox
	32	Action:Click on element (114)
	36	Action:Select "Áo sơ mi" from Áo Phông listbox
	39	Action:Type "120000" in Giá nhập textbox
	42	Action:Type "240000" in Giá bán textbox
	44	Action:Type "Áo sơ mi dai tay Nam" in textbox (16) textbox
	45	Action:Click on Lưu gridcell
	47	Action:Click on Thêm gridcell
	52	Action:Click on Kiểm kho
*/
};
