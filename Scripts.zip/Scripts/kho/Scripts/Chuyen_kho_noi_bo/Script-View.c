   !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
   !!                                                                               !!
   !!                    	  PLEASE NOTE											!!
   !!                   	  ===========											!!
   !!                                                                               !!
   !!    This view is a READ-ONLY representation of the script.                     !!
   !!                                                                               !!
   !!    Use the Firefox TruClient sidebar to develop, edit and enhance the script. !!
   !!                                                                               !!
   !!    Select the DEVELOP SCRIPT button to open the Firefox TruClient sidebar.    !!
   !!                                                                               !!
   !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!


F(){
/*
	1	Action:Navigate to "http://bo.ezmall.vn/"
	4	Action:Type "demo" in Tên đăng nhập textbox
	5	Action:Type ●●●●●●●●● in Mật khẩu passwordbox
	6	Action:Type "10002" in Mã cửa hàng textbox
	8	Action:Click on Đăng nhập gridcell
	10	Action:Click on button button
	12	Action:Click on KHO
	14	Action:Click on Chuyển kho nội bộ
	16	Action:Click on Thêm mới gridcell
	18	Action:Click on Kho nhận
	19	Action:Mouse Over
	19.1	Action:Move mouse over Kho bán gridcell
	20	Action:Click on Kho bán textbox
	24	Action:Click on Kho bán gridcell
	28	Action:Click on Kho bán textbox
	32	Action:Double click on Kho bán textbox
	34	Action:Select "Kho lưu" from Kho bán listbox
	36	Action:Type "b" in Hủy hàng textbox
	38	Action:Select "23456tyy76-Quần Bò" from Hủy hàng autocomplete
	39	Action:Click on Thêm gridcell
	41	Action:Click on Lưu gridcell
*/
};
